package com.cutm.rideease.screens.auth

import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.platform.LocalContext
import androidx.navigation.NavController
import com.cutm.rideease.R
import com.cutm.rideease.navigation.AppRoute
import com.cutm.rideease.data.UserDataManager

enum class UserRole {
    USER, EMPLOYEE, MANAGER
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AuthScreen(
    navController: NavController,
    isLogin: Boolean = true
) {
    var email by remember { mutableStateOf("") }
    var password by remember { mutableStateOf("") }
    var emailError by remember { mutableStateOf("") }
    var name by remember { mutableStateOf("") }
    
    // Get the current context for UserDataManager
    val context = LocalContext.current
    val userDataManager = remember { UserDataManager.getInstance(context) }
    
    Surface(
        modifier = Modifier.fillMaxSize(),
        color = MaterialTheme.colorScheme.background
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(horizontal = 32.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Image(
                painter = painterResource(id = R.drawable.cutm),
                contentDescription = "CUTM Logo",
                modifier = Modifier
                    .size(200.dp)
                    .padding(bottom = 15.dp)
            )
            
            Text(
                text = if (isLogin) "Welcome" else "Create Account",
                style = MaterialTheme.typography.headlineLarge
            )
            
            Spacer(modifier = Modifier.height(32.dp))
            
            if (!isLogin) {
                OutlinedTextField(
                    value = name,
                    onValueChange = { name = it },
                    label = { Text("Full Name") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth(),
                    keyboardOptions = KeyboardOptions(
                        imeAction = ImeAction.Next
                    )
                )
                
                Spacer(modifier = Modifier.height(16.dp))
            }
            
            OutlinedTextField(
                value = email,
                onValueChange = {
                    email = it
                    emailError = when {
                        it.endsWith("@student.cutm.ac.in") -> ""
                        it.endsWith("@employee.cutm.ac.in") -> ""
                        it.endsWith("@manager.cutm.ac.in") -> ""
                        else -> "Please use your official CUTM email address"
                    }
                },
                label = { Text("Email") },
                singleLine = true,
                modifier = Modifier.fillMaxWidth(),
                isError = emailError.isNotEmpty(),
                supportingText = { if(emailError.isNotEmpty()) Text(emailError) },
                keyboardOptions = KeyboardOptions(
                    keyboardType = KeyboardType.Email,
                    imeAction = ImeAction.Next
                )
            )
            
            Spacer(modifier = Modifier.height(16.dp))
            
            OutlinedTextField(
                value = password,
                onValueChange = { password = it },
                label = { Text("Password") },
                singleLine = true,
                modifier = Modifier.fillMaxWidth(),
                visualTransformation = PasswordVisualTransformation(),
                keyboardOptions = KeyboardOptions(
                    keyboardType = KeyboardType.Password,
                    imeAction = ImeAction.Done
                )
            )
            
            Spacer(modifier = Modifier.height(24.dp))

            
            Button(
                onClick = {
                    val isValidEmail = email.endsWith("@student.cutm.ac.in") ||
                        email.endsWith("@employee.cutm.ac.in") ||
                        email.endsWith("@manager.cutm.ac.in")

                        if (isValidEmail) {
                            if (isLogin) {
                                if (password.isNotBlank()) {
                                    val role = determineUserRole(email)
                                    val destination = when (role) {
                                        UserRole.USER -> AppRoute.User.Dashboard
                                        UserRole.EMPLOYEE -> AppRoute.Employee.Dashboard
                                        UserRole.MANAGER -> AppRoute.Manager.Dashboard
                                    }
                                    navController.navigate(destination) {
                                        popUpTo(0) { inclusive = true }
                                        launchSingleTop = true
                                    }
                                }
                            } else {
                                if (name.isNotBlank() && password.isNotBlank()) {
                                    // Save user data when signing up
                                    val role = determineUserRole(email)
                                    userDataManager.saveUserInfo(
                                        name = name,
                                        email = email,
                                        role = role.toString()
                                    )
                                    navController.navigate(AppRoute.Auth.Login) {
                                        popUpTo(AppRoute.Auth.SignUp) { inclusive = true }
                                    }
                                }
                            }
                        } else {
                            emailError = "Invalid email"
                        }
                },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(50.dp)
            ) {
                Text(if (isLogin) "Login" else "Sign Up")
            }
            
            TextButton(
                onClick = {
                    val route = if (isLogin) AppRoute.Auth.SignUp else AppRoute.Auth.Login
                    navController.navigate(route)
                }
            ) {
                Text(
                    if (isLogin) "Don't have an account? Sign Up"
                    else "Already have an account? Login"
                )
            }
        }
    }
}

private fun determineUserRole(email: String): UserRole {
    return when {
        email.endsWith("@student.cutm.ac.in") -> UserRole.USER
        email.endsWith("@employee.cutm.ac.in") -> UserRole.EMPLOYEE
        email.endsWith("@manager.cutm.ac.in") -> UserRole.MANAGER
        else -> UserRole.USER
    }
}