package com.cutm.rideease.navigation

object AppRoute {
    object Auth {
        const val Login = "login"
        const val SignUp = "signup"
    }

    object User {
        const val Dashboard = "user_dashboard"
        const val Profile = "profile"
        const val History = "history"
        const val Feedback = "feedback"
        const val RideNow = "ride_now"
        const val TypeSelection = "type_selection"
        const val FareEstimate = "fare_estimate"
        const val Payment = "payment"
        const val QRScanner = "qr_scanner"
        const val CycleList = "cycle_list"
        const val RideTracking = "ride_tracking"
    }

    object Employee {
        const val Dashboard = "employee_dashboard"
        const val PaymentConfirmation = "payment_confirmation"
        const val MaintenanceList = "maintenance_list/{cycleType}"
        const val FeedbackReview = "feedback_review"
    }

    object Manager {
        const val Dashboard = "manager_dashboard"
        const val Revenue = "revenue_dashboard"
        const val Analytics = "ride_analytics"
        const val UserManagement = "user_management"
        const val Maintenance = "maintenance_tracking"
        const val FeedbackSystem = "feedback_system"
        const val Settings = "settings"
    }
}