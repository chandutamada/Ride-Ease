package com.cutm.rideease.screens.employee

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import com.cutm.rideease.navigation.AppRoute

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun CycleTypeSelectionScreen(navController: NavController) {
    val categories = listOf("Mountain E-Bike", "City Cruiser", "Sport E-Bike", "Comfort Rider")
    
    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Manage Cycle Types") },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = Color(0xFFFCE93B),
                    titleContentColor = Color.Black,
                    navigationIconContentColor = Color.Black,
                    actionIconContentColor = Color.Black
                )
            )
        }
    ) { padding ->
        LazyVerticalGrid(
            columns = GridCells.Fixed(2),
            modifier = Modifier.padding(padding),
            verticalArrangement = Arrangement.spacedBy(16.dp),
            horizontalArrangement = Arrangement.spacedBy(16.dp),
            contentPadding = PaddingValues(16.dp)
        ) {
            items(categories) { type ->
                Card(
                    onClick = { navController.navigate("${AppRoute.User.CycleList}/$type") },
                    modifier = Modifier.height(150.dp)
                ) {
                    Box(
                        modifier = Modifier.fillMaxSize(),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = type,
                            style = MaterialTheme.typography.titleMedium
                        )
                    }
                }
            }
        }
    }
}