package com.cutm.rideease.screens.user

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import android.widget.Toast

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun CycleListScreen(
    navController: NavController,
    type: String
) {
    val context = LocalContext.current
    val allCycles = remember {
        listOf(
            // Mountain E-Bikes
            Cycle("M1", "Mountain E-Bike Pro", "Mountain E-Bike", 85, 45.5, 25.0, true),
            Cycle("M2", "Mountain E-Bike Sport", "Mountain E-Bike", 70, 40.0, 23.0, false),
            Cycle("M3", "Mountain E-Bike Trail", "Mountain E-Bike", 90, 50.0, 28.0, true),
            Cycle("M4", "Mountain E-Bike Lite", "Mountain E-Bike", 65, 35.0, 22.0, false),
            Cycle("M5", "Mountain E-Bike Extreme", "Mountain E-Bike", 95, 55.0, 30.0, true),
            
            // City Cruisers
            Cycle("C1", "City Cruiser Deluxe", "City Cruiser", 80, 38.0, 20.0, true),
            Cycle("C2", "City Cruiser Comfort", "City Cruiser", 75, 35.0, 18.0, false),
            Cycle("C3", "City Cruiser Urban", "City Cruiser", 90, 42.0, 22.0, true),
            Cycle("C4", "City Cruiser Classic", "City Cruiser", 85, 40.0, 19.0, true),
            Cycle("C5", "City Cruiser Eco", "City Cruiser", 70, 32.0, 17.0, false),
            
            // Sport E-Bikes
            Cycle("S1", "Sport E-Bike Racing", "Sport E-Bike", 95, 48.0, 32.0, true),
            Cycle("S2", "Sport E-Bike Speed", "Sport E-Bike", 90, 45.0, 30.0, false),
            Cycle("S3", "Sport E-Bike Pro", "Sport E-Bike", 85, 42.0, 28.0, true),
            Cycle("S4", "Sport E-Bike Turbo", "Sport E-Bike", 80, 40.0, 29.0, false),
            Cycle("S5", "Sport E-Bike Elite", "Sport E-Bike", 100, 50.0, 35.0, true),
            
            // Comfort Riders
            Cycle("R1", "Comfort Rider Plush", "Comfort Rider", 75, 36.0, 18.0, true),
            Cycle("R2", "Comfort Rider Relax", "Comfort Rider", 80, 38.0, 19.0, false),
            Cycle("R3", "Comfort Rider Smooth", "Comfort Rider", 85, 40.0, 20.0, true),
            Cycle("R4", "Comfort Rider Gentle", "Comfort Rider", 70, 34.0, 17.0, true),
            Cycle("R5", "Comfort Rider Luxury", "Comfort Rider", 90, 42.0, 21.0, false)
        )
    }

    val filteredCycles = allCycles.filter { it.type == type }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(type) },
                navigationIcon = {
                    IconButton(onClick = { navController.popBackStack() }) {
                        Icon(Icons.Default.ArrowBack, contentDescription = "Back")
                    }
                }
            )
        }
    ) { padding ->
        LazyColumn(
            modifier = Modifier
                .padding(padding)
                .padding(16.dp)
        ) {
            items(filteredCycles) { cycle ->
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 8.dp),
                    colors = CardDefaults.cardColors(
                        containerColor = if (cycle.isAvailable) MaterialTheme.colorScheme.surfaceVariant
                        else MaterialTheme.colorScheme.errorContainer
                    ),
                    onClick = {
                        if (cycle.isAvailable) {
                            navController.navigate(com.cutm.rideease.navigation.AppRoute.User.QRScanner) {
                                launchSingleTop = true
                                restoreState = true
                                popUpTo(com.cutm.rideease.navigation.AppRoute.User.CycleList) {
                                    saveState = true
                                }
                            }
                        } else {
                            Toast.makeText(context, "Cycle is currently in use", Toast.LENGTH_SHORT).show()
                        }
                    }
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Text(
                            text = cycle.name,
                            style = MaterialTheme.typography.titleLarge
                        )
                        
                        Spacer(modifier = Modifier.height(8.dp))
                        
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Column {
                                Text(
                                    text = "Battery: ${cycle.batteryPercentage}%",
                                    style = MaterialTheme.typography.bodyMedium
                                )
                                
                                Text(
                                    text = "Range: ${cycle.distanceRange} km",
                                    style = MaterialTheme.typography.bodyMedium
                                )
                            }
                            
                            Column {
                                Text(
                                    text = "Top Speed: ${cycle.topSpeed} km/h",
                                    style = MaterialTheme.typography.bodyMedium
                                )
                                
                                Text(
                                    text = "Status: ${if (cycle.isAvailable) "Available" else "In Use"}",
                                    style = MaterialTheme.typography.bodyMedium,
                                    color = if (cycle.isAvailable) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.error
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}