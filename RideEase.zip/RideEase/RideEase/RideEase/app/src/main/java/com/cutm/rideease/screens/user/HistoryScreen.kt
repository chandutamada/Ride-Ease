package com.cutm.rideease.screens.user

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.CalendarMonth
import androidx.compose.material.icons.filled.DirectionsBike
import androidx.compose.material.icons.filled.Route
import androidx.compose.material.icons.filled.Speed
import androidx.compose.material.icons.filled.Timer
import com.cutm.rideease.utils.DateTimeUtils.formatDuration
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import java.text.SimpleDateFormat
import java.util.*


// Data class to represent a past ride
data class RideHistory(
    val id: String,
    val cycleName: String,
    val cycleId: String,
    val date: Date,
    val duration: Long, // in seconds
    val distance: Float, // in kilometers
    val averageSpeed: Float, // in km/h
    val caloriesBurned: Int,
    val startLocation: String,
    val endLocation: String,
    val cost: Double
)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HistoryScreen(navController: NavController) {
    // Sample ride history data
    val rideHistoryList = remember {
        listOf(
            RideHistory(
                id = "R1001",
                cycleName = "Mountain E-Bike Pro",
                cycleId = "M1",
                date = Calendar.getInstance().apply { add(Calendar.DAY_OF_YEAR, -1) }.time,
                duration = 1800, // 30 minutes
                distance = 8.5f,
                averageSpeed = 17.0f,
                caloriesBurned = 150,
                startLocation = "Central Park",
                endLocation = "Downtown",
                cost = 25.50
            ),
            RideHistory(
                id = "R1002",
                cycleName = "City Cruiser Deluxe",
                cycleId = "C1",
                date = Calendar.getInstance().apply { add(Calendar.DAY_OF_YEAR, -3) }.time,
                duration = 2700, // 45 minutes
                distance = 12.0f,
                averageSpeed = 16.0f,
                caloriesBurned = 200,
                startLocation = "University Campus",
                endLocation = "Shopping Mall",
                cost = 35.75
            ),
            RideHistory(
                id = "R1003",
                cycleName = "Sport E-Bike Racing",
                cycleId = "S1",
                date = Calendar.getInstance().apply { add(Calendar.DAY_OF_YEAR, -7) }.time,
                duration = 3600, // 60 minutes
                distance = 20.0f,
                averageSpeed = 20.0f,
                caloriesBurned = 300,
                startLocation = "Riverside Park",
                endLocation = "Beach Front",
                cost = 45.00
            )
        )
    }
    
    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Ride History") },
                navigationIcon = {
                    IconButton(onClick = { navController.popBackStack() }) {
                        Icon(Icons.Default.ArrowBack, contentDescription = "Back")
                    }
                }
            )
        }
    ) { padding ->
        if (rideHistoryList.isEmpty()) {
            // Empty state
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(padding)
                    .padding(16.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.Center
            ) {
                Icon(
                    imageVector = Icons.Default.DirectionsBike,
                    contentDescription = null,
                    modifier = Modifier.size(72.dp),
                    tint = MaterialTheme.colorScheme.primary.copy(alpha = 0.6f)
                )
                
                Spacer(modifier = Modifier.height(16.dp))
                
                Text(
                    text = "No ride history yet",
                    style = MaterialTheme.typography.titleLarge,
                    textAlign = TextAlign.Center
                )
                
                Spacer(modifier = Modifier.height(8.dp))
                
                Text(
                    text = "Your completed rides will appear here",
                    style = MaterialTheme.typography.bodyMedium,
                    textAlign = TextAlign.Center,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        } else {
            // List of ride history
            LazyColumn(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(padding)
                    .padding(horizontal = 16.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp),
                contentPadding = PaddingValues(vertical = 16.dp)
            ) {
                items(rideHistoryList) { ride ->
                    RideHistoryCard(
                        ride = ride,
                        onClick = {
                            // Navigate to ride details screen
                            // navController.navigate("${AppRoute.User.RideDetails}/${ride.id}")
                        }
                    )
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun RideHistoryCard(ride: RideHistory, onClick: () -> Unit) {
    val dateFormat = remember { SimpleDateFormat("MMM dd, yyyy HH:mm", Locale.getDefault()) }
    
    Card(
        modifier = Modifier
            .fillMaxWidth(),
        onClick = onClick
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp)
        ) {
            // Date and Cycle Info
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.CalendarMonth,
                        contentDescription = null,
                        tint = MaterialTheme.colorScheme.primary,
                        modifier = Modifier.size(20.dp)
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(
                        text = dateFormat.format(ride.date),
                        style = MaterialTheme.typography.bodyMedium
                    )
                }
                
                Text(
                    text = "₹${String.format("%.2f", ride.cost)}",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.primary
                )
            }
            
            Spacer(modifier = Modifier.height(8.dp))
            
            // Cycle name and ID
            Text(
                text = ride.cycleName,
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold
            )
            
            Text(
                text = "Cycle ID: ${ride.cycleId}",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            
            Spacer(modifier = Modifier.height(12.dp))
            
            // Route info
            Text(
                text = "${ride.startLocation} → ${ride.endLocation}",
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            
            Spacer(modifier = Modifier.height(12.dp))
            
            // Ride metrics
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                // Distance
                RideMetricItem(
                    icon = Icons.Default.Route,
                    value = String.format("%.1f km", ride.distance)
                )
                
                // Duration
                RideMetricItem(
                    icon = Icons.Default.Timer,
                    value = formatDuration(ride.duration)
                )
                
                // Speed
                RideMetricItem(
                    icon = Icons.Default.Speed,
                    value = String.format("%.1f km/h", ride.averageSpeed)
                )
            }
        }
    }
}

@Composable
fun RideMetricItem(icon: androidx.compose.ui.graphics.vector.ImageVector, value: String) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Icon(
            imageVector = icon,
            contentDescription = null,
            tint = MaterialTheme.colorScheme.primary,
            modifier = Modifier.size(16.dp)
        )
        Spacer(modifier = Modifier.width(4.dp))
        Text(
            text = value,
            style = MaterialTheme.typography.bodySmall
        )
    }
}

