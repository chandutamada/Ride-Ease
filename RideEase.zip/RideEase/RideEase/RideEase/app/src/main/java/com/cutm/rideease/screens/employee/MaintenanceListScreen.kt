package com.cutm.rideease.screens.employee

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Build
import androidx.compose.material.icons.filled.CalendarToday
import androidx.compose.material.icons.filled.Person
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController

enum class MaintenancePriority {
    HIGH, MEDIUM, LOW
}

enum class MaintenanceStatus {
    PENDING, IN_PROGRESS, COMPLETED
}

data class MaintenanceTask(
    val title: String,
    val description: String,
    val priority: MaintenancePriority,
    val status: MaintenanceStatus,
    val dueDate: String,
    val assignedTo: String?
)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MaintenanceListScreen(
    navController: NavController,
    cycleType: String,
    modifier: Modifier = Modifier
) {
    val maintenanceTasks = remember {
        when (cycleType) {
            "Mountain E-Bike" -> listOf(
                MaintenanceTask(
                    "Check Suspension System",
                    "Inspect front and rear suspension for proper function and wear",
                    MaintenancePriority.HIGH,
                    MaintenanceStatus.PENDING,
                    "2025-03-20",
                    "John Smith"
                ),
                MaintenanceTask(
                    "Battery Health Check",
                    "Test battery capacity and charging system",
                    MaintenancePriority.MEDIUM,
                    MaintenanceStatus.IN_PROGRESS,
                    "2025-03-18",
                    "Emma Davis"
                )
            )
            "City Cruiser" -> listOf(
                MaintenanceTask(
                    "Brake System Inspection",
                    "Check brake pads and adjust brake tension",
                    MaintenancePriority.HIGH,
                    MaintenanceStatus.PENDING,
                    "2025-03-17",
                    "Michael Brown"
                ),
                MaintenanceTask(
                    "Tire Pressure Check",
                    "Ensure proper tire pressure for optimal performance",
                    MaintenancePriority.LOW,
                    MaintenanceStatus.COMPLETED,
                    "2025-03-16",
                    null
                )
            )
            "Sport E-Bike" -> listOf(
                MaintenanceTask(
                    "Motor Performance Test",
                    "Check motor output and efficiency metrics",
                    MaintenancePriority.HIGH,
                    MaintenanceStatus.IN_PROGRESS,
                    "2025-03-19",
                    "Sarah Wilson"
                ),
                MaintenanceTask(
                    "Gear System Maintenance",
                    "Inspect and adjust gear shifting mechanism",
                    MaintenancePriority.MEDIUM,
                    MaintenanceStatus.PENDING,
                    "2025-03-21",
                    "David Lee"
                )
            )
            "Comfort Rider" -> listOf(
                MaintenanceTask(
                    "Comfort Features Check",
                    "Inspect seat suspension and ergonomic components",
                    MaintenancePriority.MEDIUM,
                    MaintenanceStatus.PENDING,
                    "2025-03-18",
                    "Lisa Chen"
                ),
                MaintenanceTask(
                    "Light System Inspection",
                    "Test all lighting components and wiring",
                    MaintenancePriority.LOW,
                    MaintenanceStatus.COMPLETED,
                    "2025-03-15",
                    null
                )
            )
            else -> emptyList()
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("$cycleType Maintenance") },
                navigationIcon = {
                    IconButton(onClick = { navController.popBackStack() }) {
                        Icon(Icons.Default.ArrowBack, contentDescription = "Back")
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = Color(0xFFFFEB3B),
                    titleContentColor = Color.Black,
                    navigationIconContentColor = Color.Black
                )
            )
        }
    ) { padding ->
        LazyColumn(
            contentPadding = PaddingValues(
                top = padding.calculateTopPadding(),
                bottom = padding.calculateBottomPadding() + 16.dp,
                start = 16.dp,
                end = 16.dp
            ),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            items(maintenanceTasks) { task ->
                MaintenanceTaskCard(task = task)
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MaintenanceTaskCard(task: MaintenanceTask) {
    val cardColor = when (task.priority) {
        MaintenancePriority.HIGH -> Color(0xFFFFEBEE)
        MaintenancePriority.MEDIUM -> Color(0xFFFFF3E0)
        MaintenancePriority.LOW -> Color(0xFFF1F8E9)
    }

    val statusColor = when (task.status) {
        MaintenanceStatus.PENDING -> Color(0xFFF44336)
        MaintenanceStatus.IN_PROGRESS -> Color(0xFFFFA000)
        MaintenanceStatus.COMPLETED -> Color(0xFF4CAF50)
    }

    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = cardColor)
    ) {
        Column(
            modifier = Modifier
                .padding(16.dp)
                .fillMaxWidth()
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = task.title,
                    style = MaterialTheme.typography.titleMedium,
                    color = Color.Black
                )
                AssistChip(
                    onClick = { },
                    label = { Text(task.status.name) },
                    leadingIcon = { Icon(Icons.Default.Build, contentDescription = null) },
                    colors = AssistChipDefaults.assistChipColors(
                        leadingIconContentColor = statusColor,
                        labelColor = statusColor
                    )
                )
            }

            Spacer(modifier = Modifier.height(8.dp))
            
            Text(
                text = task.description,
                style = MaterialTheme.typography.bodyMedium,
                color = Color.Black.copy(alpha = 0.7f),
                maxLines = 2,
                overflow = TextOverflow.Ellipsis
            )

            Spacer(modifier = Modifier.height(12.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        Icons.Default.CalendarToday,
                        contentDescription = "Due Date",
                        tint = Color.Black.copy(alpha = 0.6f),
                        modifier = Modifier.size(16.dp)
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(
                        text = "Due: ${task.dueDate}",
                        style = MaterialTheme.typography.bodySmall,
                        color = Color.Black.copy(alpha = 0.6f)
                    )
                }

                task.assignedTo?.let { assignee ->
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            Icons.Default.Person,
                            contentDescription = "Assigned To",
                            tint = Color.Black.copy(alpha = 0.6f),
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(
                            text = assignee,
                            style = MaterialTheme.typography.bodySmall,
                            color = Color.Black.copy(alpha = 0.6f)
                        )
                    }
                }
            }
        }
    }
}
