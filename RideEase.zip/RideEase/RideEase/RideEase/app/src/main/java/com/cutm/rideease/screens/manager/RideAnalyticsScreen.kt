package com.cutm.rideease.screens.manager

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import java.text.SimpleDateFormat
import java.util.*

data class RideAnalytics(
    val totalRides: Int,
    val activeRides: Int,
    val averageRideDistance: Double,
    val averageRideDuration: Int,
    val popularRoutes: List<RouteAnalytics>,
    val peakHours: List<HourlyAnalytics>,
    val weeklyTrends: List<DailyAnalytics>
)

data class RouteAnalytics(
    val startPoint: String,
    val endPoint: String,
    val frequency: Int,
    val averageTime: Int
)

data class HourlyAnalytics(
    val hour: Int,
    val rideCount: Int
)

data class DailyAnalytics(
    val date: Date,
    val rideCount: Int,
    val revenue: Double
)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun RideAnalyticsScreen(navController: NavController) {
    var analytics by remember {
        mutableStateOf(
            RideAnalytics(
                totalRides = 1250,
                activeRides = 45,
                averageRideDistance = 5.2,
                averageRideDuration = 25,
                popularRoutes = listOf(
                    RouteAnalytics("University Campus", "Shopping Mall", 450, 20),
                    RouteAnalytics("Metro Station", "Tech Park", 380, 15),
                    RouteAnalytics("Residential Area", "Market", 320, 18)
                ),
                peakHours = listOf(
                    HourlyAnalytics(9, 120),
                    HourlyAnalytics(17, 150),
                    HourlyAnalytics(19, 85)
                ),
                weeklyTrends = listOf(
                    DailyAnalytics(Date(), 180, 9000.0),
                    DailyAnalytics(Date(System.currentTimeMillis() - 86400000), 165, 8250.0),
                    DailyAnalytics(Date(System.currentTimeMillis() - 2 * 86400000), 195, 9750.0)
                )
            )
        )
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Ride Analytics") },
                navigationIcon = {
                    IconButton(onClick = { navController.popBackStack() }) {
                        Icon(Icons.Default.ArrowBack, "Back")
                    }
                },
                actions = {
                    IconButton(onClick = { /* Export analytics */ }) {
                        Icon(Icons.Default.Download, "Export")
                    }
                }
            )
        }
    ) { padding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            item { OverviewCard(analytics) }
            item { PopularRoutesCard(analytics.popularRoutes) }
            item { PeakHoursCard(analytics.peakHours) }
            item { WeeklyTrendsCard(analytics.weeklyTrends) }
        }
    }
}

@Composable
private fun OverviewCard(analytics: RideAnalytics) {
    Card(
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(
            modifier = Modifier.padding(16.dp)
        ) {
            Text(
                text = "Overview",
                style = MaterialTheme.typography.titleLarge,
                fontWeight = FontWeight.Bold
            )
            
            Spacer(modifier = Modifier.height(16.dp))
            
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                StatItem(
                    value = analytics.totalRides.toString(),
                    label = "Total Rides",
                    icon = Icons.Default.DirectionsBike
                )
                StatItem(
                    value = analytics.activeRides.toString(),
                    label = "Active Rides",
                    icon = Icons.Default.Timer
                )
                StatItem(
                    value = String.format("%.1f km", analytics.averageRideDistance),
                    label = "Avg Distance",
                    icon = Icons.Default.Route
                )
                StatItem(
                    value = "${analytics.averageRideDuration} min",
                    label = "Avg Duration",
                    icon = Icons.Default.Schedule
                )
            }
        }
    }
}

@Composable
private fun PopularRoutesCard(routes: List<RouteAnalytics>) {
    Card(
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(
            modifier = Modifier.padding(16.dp)
        ) {
            Text(
                text = "Popular Routes",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold
            )
            
            Spacer(modifier = Modifier.height(16.dp))
            
            routes.forEach { route ->
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 8.dp),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Column {
                        Text(
                            text = "${route.startPoint} → ${route.endPoint}",
                            style = MaterialTheme.typography.bodyMedium
                        )
                        Text(
                            text = "${route.frequency} rides • Avg ${route.averageTime} min",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun PeakHoursCard(hours: List<HourlyAnalytics>) {
    Card(
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(
            modifier = Modifier.padding(16.dp)
        ) {
            Text(
                text = "Peak Hours",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold
            )
            
            Spacer(modifier = Modifier.height(16.dp))
            
            hours.forEach { hour ->
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 8.dp),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text(
                        text = "${hour.hour}:00",
                        style = MaterialTheme.typography.bodyMedium
                    )
                    Text(
                        text = "${hour.rideCount} rides",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
        }
    }
}

@Composable
private fun WeeklyTrendsCard(trends: List<DailyAnalytics>) {
    Card(
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(
            modifier = Modifier.padding(16.dp)
        ) {
            Text(
                text = "Weekly Trends",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold
            )
            
            Spacer(modifier = Modifier.height(16.dp))
            
            trends.forEach { trend ->
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 8.dp),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text(
                        text = SimpleDateFormat("MMM dd", Locale.getDefault()).format(trend.date),
                        style = MaterialTheme.typography.bodyMedium
                    )
                    Column(
                        horizontalAlignment = Alignment.End
                    ) {
                        Text(
                            text = "${trend.rideCount} rides",
                            style = MaterialTheme.typography.bodyMedium
                        )
                        Text(
                            text = "₹${trend.revenue}",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun StatItem(value: String, label: String, icon: ImageVector) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Icon(imageVector = icon, contentDescription = label, modifier = Modifier.size(24.dp), tint = MaterialTheme.colorScheme.primary)
        Spacer(modifier = Modifier.height(4.dp))
        Text(text = value, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
        Text(text = label, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
    }
}