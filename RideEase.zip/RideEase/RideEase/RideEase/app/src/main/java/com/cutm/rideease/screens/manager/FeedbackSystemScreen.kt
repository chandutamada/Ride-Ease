package com.cutm.rideease.screens.manager

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import java.text.SimpleDateFormat
import java.util.*

data class UserFeedback(
    val id: String,
    val userId: String,
    val userName: String,
    val cycleId: String,
    val cycleName: String,
    val rating: Int,
    val comment: String,
    val date: Date,
    val rideId: String,
    val resolved: Boolean = false
)

data class FeedbackStats(
    val totalFeedbacks: Int,
    val averageRating: Float,
    val fiveStarCount: Int,
    val fourStarCount: Int,
    val threeStarCount: Int,
    val twoStarCount: Int,
    val oneStarCount: Int
)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun FeedbackSystemScreen(navController: NavController) {
    var feedbacks by remember {
        mutableStateOf(
            listOf(
                UserFeedback(
                    id = "F001",
                    userId = "U1001",
                    userName = "Rahul Sharma",
                    cycleId = "C1",
                    cycleName = "City Cruiser Deluxe",
                    rating = 5,
                    comment = "Excellent ride experience! The bike was in perfect condition.",
                    date = Calendar.getInstance().apply { add(Calendar.DAY_OF_YEAR, -1) }.time,
                    rideId = "R1001"
                ),
                UserFeedback(
                    id = "F002",
                    userId = "U1002",
                    userName = "Priya Patel",
                    cycleId = "M1",
                    cycleName = "Mountain E-Bike Pro",
                    rating = 4,
                    comment = "Good bike, but battery could be better.",
                    date = Calendar.getInstance().apply { add(Calendar.DAY_OF_YEAR, -2) }.time,
                    rideId = "R1002"
                ),
                UserFeedback(
                    id = "F003",
                    userId = "U1003",
                    userName = "Amit Kumar",
                    cycleId = "S1",
                    cycleName = "Sport E-Bike Racing",
                    rating = 5,
                    comment = "Amazing speed and comfort! Will definitely use again.",
                    date = Calendar.getInstance().apply { add(Calendar.DAY_OF_YEAR, -3) }.time,
                    rideId = "R1003"
                ),
                UserFeedback(
                    id = "F004",
                    userId = "U1004",
                    userName = "Neha Singh",
                    cycleId = "C2",
                    cycleName = "City Cruiser Standard",
                    rating = 3,
                    comment = "The ride was okay, but the seat was uncomfortable for longer trips.",
                    date = Calendar.getInstance().apply { add(Calendar.DAY_OF_YEAR, -4) }.time,
                    rideId = "R1004"
                ),
                UserFeedback(
                    id = "F005",
                    userId = "U1005",
                    userName = "Vikram Malhotra",
                    cycleId = "M2",
                    cycleName = "Mountain E-Bike Standard",
                    rating = 2,
                    comment = "The brakes were not working properly. Please fix this issue.",
                    date = Calendar.getInstance().apply { add(Calendar.DAY_OF_YEAR, -5) }.time,
                    rideId = "R1005",
                    resolved = true
                ),
                UserFeedback(
                    id = "F006",
                    userId = "U1006",
                    userName = "Ananya Reddy",
                    cycleId = "S2",
                    cycleName = "Sport E-Bike Standard",
                    rating = 1,
                    comment = "Very poor experience. The cycle had multiple issues and I had to end my ride early.",
                    date = Calendar.getInstance().apply { add(Calendar.DAY_OF_YEAR, -6) }.time,
                    rideId = "R1006"
                )
            )
        )
    }

    // Calculate feedback statistics
    val stats = remember(feedbacks) {
        val totalCount = feedbacks.size
        val totalRating = feedbacks.sumOf { it.rating }
        val avgRating = if (totalCount > 0) totalRating.toFloat() / totalCount else 0f
        
        FeedbackStats(
            totalFeedbacks = totalCount,
            averageRating = avgRating,
            fiveStarCount = feedbacks.count { it.rating == 5 },
            fourStarCount = feedbacks.count { it.rating == 4 },
            threeStarCount = feedbacks.count { it.rating == 3 },
            twoStarCount = feedbacks.count { it.rating == 2 },
            oneStarCount = feedbacks.count { it.rating == 1 }
        )
    }

    var selectedRating by remember { mutableStateOf(0) }
    var showResolved by remember { mutableStateOf(false) }
    var selectedFeedback by remember { mutableStateOf<UserFeedback?>(null) }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Feedback Management") },
                navigationIcon = {
                    IconButton(onClick = { navController.popBackStack() }) {
                        Icon(Icons.Default.ArrowBack, contentDescription = "Back")
                    }
                },
                actions = {
                    IconButton(onClick = { showResolved = !showResolved }) {
                        Icon(
                            if (showResolved) Icons.Default.CheckCircle else Icons.Default.CheckCircleOutline,
                            contentDescription = "Toggle Resolved"
                        )
                    }
                    IconButton(onClick = { /* Export feedback data */ }) {
                        Icon(Icons.Default.Download, contentDescription = "Export")
                    }
                }
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
        ) {
            // Feedback statistics card
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp)
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp)
                ) {
                    Text(
                        text = "Feedback Overview",
                        style = MaterialTheme.typography.titleLarge,
                        fontWeight = FontWeight.Bold
                    )
                    
                    Spacer(modifier = Modifier.height(16.dp))
                    
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        StatItem(
                            value = stats.totalFeedbacks.toString(),
                            label = "Total"
                        )
                        StatItem(
                            value = String.format("%.1f", stats.averageRating),
                            label = "Avg Rating"
                        )
                        StatItem(
                            value = "${stats.fiveStarCount + stats.fourStarCount}",
                            label = "Positive"
                        )
                        StatItem(
                            value = "${stats.oneStarCount + stats.twoStarCount}",
                            label = "Negative"
                        )
                    }
                    
                    Spacer(modifier = Modifier.height(16.dp))
                    
                    // Rating distribution
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "5★",
                            modifier = Modifier.width(30.dp),
                            textAlign = TextAlign.Center
                        )
                        LinearProgressIndicator(
                            progress = if (stats.totalFeedbacks > 0) stats.fiveStarCount.toFloat() / stats.totalFeedbacks else 0f,
                            modifier = Modifier
                                .weight(1f)
                                .height(8.dp),
                            color = MaterialTheme.colorScheme.primary
                        )
                        Text(
                            text = stats.fiveStarCount.toString(),
                            modifier = Modifier.width(30.dp),
                            textAlign = TextAlign.Center
                        )
                    }
                    
                    Spacer(modifier = Modifier.height(4.dp))
                    
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "4★",
                            modifier = Modifier.width(30.dp),
                            textAlign = TextAlign.Center
                        )
                        LinearProgressIndicator(
                            progress = if (stats.totalFeedbacks > 0) stats.fourStarCount.toFloat() / stats.totalFeedbacks else 0f,
                            modifier = Modifier
                                .weight(1f)
                                .height(8.dp),
                            color = MaterialTheme.colorScheme.primary
                        )
                        Text(
                            text = stats.fourStarCount.toString(),
                            modifier = Modifier.width(30.dp),
                            textAlign = TextAlign.Center
                        )
                    }
                    
                    Spacer(modifier = Modifier.height(4.dp))
                    
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "3★",
                            modifier = Modifier.width(30.dp),
                            textAlign = TextAlign.Center
                        )
                        LinearProgressIndicator(
                            progress = if (stats.totalFeedbacks > 0) stats.threeStarCount.toFloat() / stats.totalFeedbacks else 0f,
                            modifier = Modifier
                                .weight(1f)
                                .height(8.dp),
                            color = MaterialTheme.colorScheme.tertiary
                        )
                        Text(
                            text = stats.threeStarCount.toString(),
                            modifier = Modifier.width(30.dp),
                            textAlign = TextAlign.Center
                        )
                    }
                    
                    Spacer(modifier = Modifier.height(4.dp))
                    
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "2★",
                            modifier = Modifier.width(30.dp),
                            textAlign = TextAlign.Center
                        )
                        LinearProgressIndicator(
                            progress = if (stats.totalFeedbacks > 0) stats.twoStarCount.toFloat() / stats.totalFeedbacks else 0f,
                            modifier = Modifier
                                .weight(1f)
                                .height(8.dp),
                            color = Color(0xFFFFA000)
                        )
                        Text(
                            text = stats.twoStarCount.toString(),
                            modifier = Modifier.width(30.dp),
                            textAlign = TextAlign.Center
                        )
                    }
                    
                    Spacer(modifier = Modifier.height(4.dp))
                    
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "1★",
                            modifier = Modifier.width(30.dp),
                            textAlign = TextAlign.Center
                        )
                        LinearProgressIndicator(
                            progress = if (stats.totalFeedbacks > 0) stats.oneStarCount.toFloat() / stats.totalFeedbacks else 0f,
                            modifier = Modifier
                                .weight(1f)
                                .height(8.dp),
                            color = MaterialTheme.colorScheme.error
                        )
                        Text(
                            text = stats.oneStarCount.toString(),
                            modifier = Modifier.width(30.dp),
                            textAlign = TextAlign.Center
                        )
                    }
                }
            }
            
            // Rating filter
            ScrollableTabRow(
                selectedTabIndex = selectedRating,
                modifier = Modifier.fillMaxWidth(),
                edgePadding = 16.dp
            ) {
                listOf("All", "5★", "4★", "3★", "2★", "1★").forEachIndexed { index, filter ->
                    Tab(
                        selected = selectedRating == index,
                        onClick = { selectedRating = index },
                        text = { Text(filter) }
                    )
                }
            }

            if (feedbacks.isEmpty()) {
                Box(
                    modifier = Modifier.fillMaxSize(),
                    contentAlignment = Alignment.Center
                ) {
                    Text("No feedback available")
                }
            } else {
                val filteredFeedbacks = feedbacks.filter {
                    (selectedRating == 0 || it.rating == 6 - selectedRating) &&
                    (if (showResolved) true else !it.resolved)
                }
                
                if (filteredFeedbacks.isEmpty()) {
                    Box(
                        modifier = Modifier.fillMaxSize(),
                        contentAlignment = Alignment.Center
                    ) {
                        Text("No matching feedback found")
                    }
                } else {
                    LazyColumn(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(horizontal = 16.dp),
                        verticalArrangement = Arrangement.spacedBy(12.dp),
                        contentPadding = PaddingValues(vertical = 16.dp)
                    ) {
                        items(filteredFeedbacks) { feedback ->
                            FeedbackCard(
                                feedback = feedback,
                                onMarkResolved = { 
                                    feedbacks = feedbacks.map { 
                                        if (it.id == feedback.id) it.copy(resolved = !it.resolved) else it 
                                    }
                                },
                                onViewDetails = { selectedFeedback = feedback }
                            )
                        }
                    }
                }
            }
        }
        
        // Feedback detail dialog
        selectedFeedback?.let { feedback ->
            AlertDialog(
                onDismissRequest = { selectedFeedback = null },
                title = { Text("Feedback Details") },
                text = {
                    Column {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(
                                text = "User: ",
                                fontWeight = FontWeight.Bold
                            )
                            Text(feedback.userName)
                        }
                        
                        Spacer(modifier = Modifier.height(8.dp))
                        
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(
                                text = "Cycle: ",
                                fontWeight = FontWeight.Bold
                            )
                            Text(feedback.cycleName)
                        }
                        
                        Spacer(modifier = Modifier.height(8.dp))
                        
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(
                                text = "Rating: ",
                                fontWeight = FontWeight.Bold
                            )
                            Row {
                                repeat(feedback.rating) {
                                    Icon(
                                        imageVector = Icons.Filled.Star,
                                        contentDescription = null,
                                        modifier = Modifier.size(16.dp),
                                        tint = MaterialTheme.colorScheme.primary
                                    )
                                }
                            }
                        }
                        
                        Spacer(modifier = Modifier.height(8.dp))
                        
                        Text(
                            text = "Comment:",
                            fontWeight = FontWeight.Bold
                        )
                        Text(feedback.comment)
                        
                        Spacer(modifier = Modifier.height(8.dp))
                        
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(
                                text = "Date: ",
                                fontWeight = FontWeight.Bold
                            )
                            val dateFormat = SimpleDateFormat("MMM dd, yyyy", Locale.getDefault())
                            Text(dateFormat.format(feedback.date))
                        }
                        
                        Spacer(modifier = Modifier.height(8.dp))
                        
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(
                                text = "Ride ID: ",
                                fontWeight = FontWeight.Bold
                            )
                            Text(feedback.rideId)
                        }
                        
                        Spacer(modifier = Modifier.height(8.dp))
                        
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(
                                text = "Status: ",
                                fontWeight = FontWeight.Bold
                            )
                            Text(
                                text = if (feedback.resolved) "Resolved" else "Pending",
                                color = if (feedback.resolved) 
                                    MaterialTheme.colorScheme.primary 
                                else 
                                    MaterialTheme.colorScheme.error
                            )
                        }
                    }
                },
                confirmButton = {
                    Button(
                        onClick = {
                            feedbacks = feedbacks.map { 
                                if (it.id == feedback.id) it.copy(resolved = !it.resolved) else it 
                            }
                            selectedFeedback = null
                        }
                    ) {
                        Text(if (feedback.resolved) "Mark as Pending" else "Mark as Resolved")
                    }
                },
                dismissButton = {
                    TextButton(onClick = { selectedFeedback = null }) {
                        Text("Close")
                    }
                }
            )
        }
    }
}

@Composable
fun FeedbackCard(
    feedback: UserFeedback,
    onMarkResolved: () -> Unit,
    onViewDetails: () -> Unit
) {
    val dateFormat = SimpleDateFormat("MMM dd, yyyy", Locale.getDefault())

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 4.dp),
        onClick = onViewDetails
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = feedback.userName,
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = feedback.cycleName,
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
                
                // Rating display
                Row {
                    repeat(feedback.rating) {
                        Icon(
                            imageVector = Icons.Filled.Star,
                            contentDescription = null,
                            modifier = Modifier.size(20.dp),
                            tint = MaterialTheme.colorScheme.primary
                        )
                    }
                    repeat(5 - feedback.rating) {
                        Icon(
                            imageVector = Icons.Filled.StarBorder,
                            contentDescription = null,
                            modifier = Modifier.size(20.dp),
                            tint = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(8.dp))

            Text(
                text = feedback.comment,
                style = MaterialTheme.typography.bodyMedium,
                maxLines = 3
            )

            Spacer(modifier = Modifier.height(8.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.CalendarToday,
                        contentDescription = null,
                        modifier = Modifier.size(16.dp)
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(
                        text = dateFormat.format(feedback.date),
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }

                Row {
                    if (feedback.resolved) {
                        AssistChip(
                            onClick = { },
                            label = { Text("Resolved") },
                            leadingIcon = {
                                Icon(
                                    Icons.Default.CheckCircle,
                                    contentDescription = null,
                                    modifier = Modifier.size(16.dp)
                                )
                            }
                        )
                    } else {
                        FilledTonalIconButton(
                            onClick = onMarkResolved,
                            modifier = Modifier.size(36.dp)
                        ) {
                            Icon(
                                Icons.Default.CheckCircle,
                                contentDescription = "Mark as Resolved",
                                modifier = Modifier.size(20.dp)
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun StatItem(value: String, label: String) {
    Column(
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text(
            text = value,
            style = MaterialTheme.typography.titleLarge,
            fontWeight = FontWeight.Bold
        )
        Text(
            text = label,
            style = MaterialTheme.typography.bodySmall
        )
    }
}
