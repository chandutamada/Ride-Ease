package com.cutm.rideease.viewmodels

import android.app.Application
import android.content.Context
import android.os.Handler
import android.os.Looper
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import java.util.concurrent.TimeUnit

class SettingsViewModel(application: Application) : AndroidViewModel(application) {
    
    private val sharedPreferences = application.getSharedPreferences("ride_ease_settings", Context.MODE_PRIVATE)
    
    // Settings states
    var darkModeEnabled by mutableStateOf(false)
        private set
    
    var notificationsEnabled by mutableStateOf(true)
        private set
    
    var dataBackupEnabled by mutableStateOf(false)
        private set
    
    var autoLogoutEnabled by mutableStateOf(true)
        private set
    
    // Auto logout timer
    private var autoLogoutHandler: Handler? = null
    private var autoLogoutRunnable: Runnable? = null
    private val AUTO_LOGOUT_DELAY_MS = TimeUnit.MINUTES.toMillis(30) // 30 minutes
    
    // Logout state
    private val _logoutEvent = MutableStateFlow(false)
    val logoutEvent: StateFlow<Boolean> = _logoutEvent.asStateFlow()
    
    init {
        loadSettings()
        if (autoLogoutEnabled) {
            startAutoLogoutTimer()
        }
    }
    
    private fun loadSettings() {
        darkModeEnabled = sharedPreferences.getBoolean(KEY_DARK_MODE, false)
        notificationsEnabled = sharedPreferences.getBoolean(KEY_NOTIFICATIONS, true)
        dataBackupEnabled = sharedPreferences.getBoolean(KEY_DATA_BACKUP, false)
        autoLogoutEnabled = sharedPreferences.getBoolean(KEY_AUTO_LOGOUT, true)
    }
    
    fun toggleDarkMode(enabled: Boolean) {
        darkModeEnabled = enabled
        saveSettings(KEY_DARK_MODE, enabled)
        applyDarkMode(enabled)
    }
    
    fun toggleNotifications(enabled: Boolean) {
        notificationsEnabled = enabled
        saveSettings(KEY_NOTIFICATIONS, enabled)
        applyNotificationSettings(enabled)
    }
    
    fun toggleDataBackup(enabled: Boolean) {
        dataBackupEnabled = enabled
        saveSettings(KEY_DATA_BACKUP, enabled)
        if (enabled) {
            scheduleDataBackup()
        } else {
            cancelDataBackup()
        }
    }
    
    fun toggleAutoLogout(enabled: Boolean) {
        autoLogoutEnabled = enabled
        saveSettings(KEY_AUTO_LOGOUT, enabled)
        if (enabled) {
            startAutoLogoutTimer()
        } else {
            stopAutoLogoutTimer()
        }
    }
    
    private fun saveSettings(key: String, value: Boolean) {
        sharedPreferences.edit().putBoolean(key, value).apply()
    }
    
    private fun applyDarkMode(enabled: Boolean) {
        // In a real app, this would apply the dark mode theme
        // For now, we'll just log it
        println("Dark mode ${if (enabled) "enabled" else "disabled"}")
    }
    
    private fun applyNotificationSettings(enabled: Boolean) {
        // In a real app, this would register or unregister for notifications
        // For now, we'll just log it
        println("Notifications ${if (enabled) "enabled" else "disabled"}")
    }
    
    private fun scheduleDataBackup() {
        // In a real app, this would schedule a periodic data backup
        // For now, we'll just log it
        println("Data backup scheduled")
    }
    
    private fun cancelDataBackup() {
        // In a real app, this would cancel the scheduled data backup
        // For now, we'll just log it
        println("Data backup cancelled")
    }
    
    fun resetLogoutEvent() {
        viewModelScope.launch {
            _logoutEvent.emit(false)
        }
    }
    
    fun userActivity() {
        if (autoLogoutEnabled) {
            // Reset the auto logout timer when there's user activity
            stopAutoLogoutTimer()
            startAutoLogoutTimer()
        }
    }
    
    private fun startAutoLogoutTimer() {
        if (autoLogoutHandler == null) {
            autoLogoutHandler = Handler(Looper.getMainLooper())
        }
        
        autoLogoutRunnable = Runnable {
            // Trigger logout
            viewModelScope.launch {
                _logoutEvent.emit(true)
            }
        }
        
        autoLogoutHandler?.postDelayed(autoLogoutRunnable!!, AUTO_LOGOUT_DELAY_MS)
    }
    
    private fun stopAutoLogoutTimer() {
        autoLogoutRunnable?.let {
            autoLogoutHandler?.removeCallbacks(it)
        }
    }
    
    override fun onCleared() {
        super.onCleared()
        stopAutoLogoutTimer()
    }
    
    companion object {
        private const val KEY_DARK_MODE = "dark_mode"
        private const val KEY_NOTIFICATIONS = "notifications"
        private const val KEY_DATA_BACKUP = "data_backup"
        private const val KEY_AUTO_LOGOUT = "auto_logout"
    }
}
