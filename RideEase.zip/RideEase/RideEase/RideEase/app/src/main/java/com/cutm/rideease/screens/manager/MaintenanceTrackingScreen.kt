package com.cutm.rideease.screens.manager

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import java.text.SimpleDateFormat
import java.util.*

data class MaintenanceRecord(
    val id: String,
    val cycleId: String,
    val date: Date,
    val serviceType: String,
    val technician: String,
    val cost: Double,
    val nextDue: Date
)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MaintenanceTrackingScreen(navController: NavController) {
    val dateFormat = remember { SimpleDateFormat("MMM dd, yyyy", Locale.getDefault()) }
    
    var records by remember {
        mutableStateOf(listOf(
            MaintenanceRecord(
                "M001", "C1",
                Date(System.currentTimeMillis() - 86400000 * 7),
                "Battery Replacement", "Tech Team A", 1500.0,
                Date(System.currentTimeMillis() + 86400000 * 180)
            ),
            MaintenanceRecord(
                "M002", "M1",
                Date(System.currentTimeMillis() - 86400000 * 14),
                "Brake Service", "Tech Team B", 800.0,
                Date(System.currentTimeMillis() + 86400000 * 90)
            )
        ))
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Maintenance Tracking") },
                navigationIcon = {
                    IconButton(onClick = { navController.popBackStack() }) {
                        Icon(Icons.Default.ArrowBack, "Back")
                    }
                },
                actions = {
                    IconButton(onClick = { /* Add new maintenance record */ }) {
                        Icon(Icons.Default.Add, "Add Record")
                    }
                }
            )
        }
    ) { padding ->
        LazyColumn(
            modifier = Modifier
                .padding(padding)
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            items(records) { record ->
                MaintenanceRecordCard(record, dateFormat)
            }
        }
    }
}

@Composable
private fun MaintenanceRecordCard(record: MaintenanceRecord, dateFormat: SimpleDateFormat) {
    Card(
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(
            modifier = Modifier.padding(16.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text(
                    text = "Cycle ${record.cycleId}",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold
                )
                Text(
                    text = dateFormat.format(record.date),
                    style = MaterialTheme.typography.bodySmall
                )
            }

            Spacer(modifier = Modifier.height(8.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                InfoItem("Service Type", record.serviceType)
                InfoItem("Technician", record.technician)
            }

            Spacer(modifier = Modifier.height(8.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                InfoItem("Cost", "₹${record.cost}")
                InfoItem("Next Due", dateFormat.format(record.nextDue))
            }
        }
    }
}

@Composable
private fun InfoItem(label: String, value: String) {
    Column {
        Text(
            text = label,
            style = MaterialTheme.typography.labelSmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
        Text(
            text = value,
            style = MaterialTheme.typography.bodyMedium
        )
    }
}