package com.cutm.rideease.screens.employee

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import java.text.SimpleDateFormat
import java.util.*

data class UserFeedback(
    val id: String,
    val userId: String,
    val userName: String,
    val cycleId: String,
    val cycleName: String,
    val rating: Int,
    val comment: String,
    val date: Date,
    val rideId: String
)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun FeedbackReviewScreen(navController: NavController) {
    var feedbacks by remember {
        mutableStateOf(
            listOf(
                UserFeedback(
                    id = "F001",
                    userId = "U1001",
                    userName = "Rahul Sharma",
                    cycleId = "C1",
                    cycleName = "City Cruiser Deluxe",
                    rating = 5,
                    comment = "Excellent ride experience! The bike was in perfect condition.",
                    date = Calendar.getInstance().apply { add(Calendar.DAY_OF_YEAR, -1) }.time,
                    rideId = "R1001"
                ),
                UserFeedback(
                    id = "F002",
                    userId = "U1002",
                    userName = "Priya Patel",
                    cycleId = "M1",
                    cycleName = "Mountain E-Bike Pro",
                    rating = 4,
                    comment = "Good bike, but battery could be better.",
                    date = Calendar.getInstance().apply { add(Calendar.DAY_OF_YEAR, -2) }.time,
                    rideId = "R1002"
                ),
                UserFeedback(
                    id = "F003",
                    userId = "U1003",
                    userName = "Amit Kumar",
                    cycleId = "S1",
                    cycleName = "Sport E-Bike Racing",
                    rating = 5,
                    comment = "Amazing speed and comfort! Will definitely use again.",
                    date = Calendar.getInstance().apply { add(Calendar.DAY_OF_YEAR, -3) }.time,
                    rideId = "R1003"
                )
            )
        )
    }

    var selectedRating by remember { mutableStateOf(0) }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("User Feedback") },
                navigationIcon = {
                    IconButton(onClick = { navController.popBackStack() }) {
                        Icon(Icons.Default.ArrowBack, contentDescription = "Back")
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = Color(0xFFFCE93B),
                    titleContentColor = Color.Black,
                    navigationIconContentColor = Color.Black,
                    actionIconContentColor = Color.Black
                )
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
        ) {
            // Rating filter
            ScrollableTabRow(
                selectedTabIndex = selectedRating,
                modifier = Modifier.fillMaxWidth(),
                edgePadding = 16.dp
            ) {
                listOf("All", "5★", "4★", "3★", "2★", "1★").forEachIndexed { index, filter ->
                    Tab(
                        selected = selectedRating == index,
                        onClick = { selectedRating = index },
                        text = { Text(filter) }
                    )
                }
            }

            if (feedbacks.isEmpty()) {
                Box(
                    modifier = Modifier.fillMaxSize(),
                    contentAlignment = Alignment.Center
                ) {
                    Text("No feedback available")
                }
            } else {
                LazyColumn(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    items(
                        feedbacks.filter {
                            selectedRating == 0 || it.rating == 6 - selectedRating
                        }
                    ) { feedback ->
                        FeedbackCard(feedback)
                    }
                }
            }
        }
    }
}

@Composable
fun FeedbackCard(feedback: UserFeedback) {
    val dateFormat = remember { SimpleDateFormat("MMM dd, yyyy", Locale.getDefault()) }

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 4.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = feedback.userName,
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = feedback.cycleName,
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
                
                // Rating display
                Row {
                    repeat(feedback.rating) {
                        Icon(
                            imageVector = Icons.Filled.Star,
                            contentDescription = null,
                            modifier = Modifier.size(20.dp),
                            tint = MaterialTheme.colorScheme.primary
                        )
                    }
                    repeat(5 - feedback.rating) {
                        Icon(
                            imageVector = Icons.Filled.StarBorder,
                            contentDescription = null,
                            modifier = Modifier.size(20.dp),
                            tint = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(8.dp))

            Text(
                text = feedback.comment,
                style = MaterialTheme.typography.bodyMedium
            )

            Spacer(modifier = Modifier.height(8.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.CalendarToday,
                        contentDescription = null,
                        modifier = Modifier.size(16.dp)
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(
                        text = dateFormat.format(feedback.date),
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }

                Text(
                    text = "Ride #${feedback.rideId}",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }
    }
}