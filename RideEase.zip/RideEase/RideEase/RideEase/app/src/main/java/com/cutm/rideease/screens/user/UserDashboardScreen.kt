package com.cutm.rideease.screens.user

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.ripple.rememberRipple
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import com.cutm.rideease.navigation.AppRoute
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.layout.ContentScale
import com.cutm.rideease.R
import com.cutm.rideease.data.UserDataManager
import kotlinx.coroutines.launch

data class Cycle(
    val id: String,
    val name: String,
    val type: String,
    val batteryPercentage: Int,
    val distanceRange: Double,
    val topSpeed: Double,
    val isAvailable: Boolean
)

data class NavigationItem(
    val title: String,
    val icon: ImageVector,
    val route: String
)

data class DrawerItem(
    val title: String,
    val icon: ImageVector,
    val route: String
)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun UserDashboardScreen(
    navController: NavController,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val userDataManager = remember { UserDataManager.getInstance(context) }
    val drawerState = rememberDrawerState(initialValue = DrawerValue.Closed)
    val scope = rememberCoroutineScope()

    var cycles by remember { mutableStateOf(listOf(
        Cycle("1", "Mountain E-Bike", "Mountain", 85, 45.5, 25.0, true),
        Cycle("2", "City Cruiser", "City", 70, 30.0, 20.0, true),
        Cycle("3", "Sport E-Bike", "Sport", 90, 50.0, 28.0, false),
        Cycle("4", "Comfort Rider", "Comfort", 65, 35.0, 22.0, true)
    )) }

    val navigationItems = listOf(
        NavigationItem("Payment", Icons.Default.Payment, AppRoute.User.Payment),
        NavigationItem("Ride Now", Icons.Filled.DirectionsBike, AppRoute.User.RideNow),
        NavigationItem("Fare Estimate", Icons.Default.Calculate, AppRoute.User.FareEstimate)
    )

    val drawerItems = listOf(
        DrawerItem("Profile", Icons.Default.Person, AppRoute.User.Profile),
        DrawerItem("Ride History", Icons.Default.History, AppRoute.User.History),
        DrawerItem("Payment History", Icons.Default.Payment, AppRoute.User.Payment),
        DrawerItem("Feedback", Icons.Default.Feedback, AppRoute.User.Feedback)
    )

    var selectedItem by remember { mutableStateOf(1) }
    var showSearch by remember { mutableStateOf(false) }

    ModalNavigationDrawer(
        drawerState = drawerState,
        drawerContent = {
            ModalDrawerSheet {
                Spacer(modifier = Modifier.height(16.dp))
                Text(
                    "RideEase Menu",
                    modifier = Modifier.padding(16.dp),
                    style = MaterialTheme.typography.titleLarge
                )
                Divider()
                drawerItems.forEach { item ->
                    NavigationDrawerItem(
                        icon = { Icon(item.icon, contentDescription = null) },
                        label = { Text(item.title) },
                        selected = false,
                        onClick = {
                            scope.launch {
                                drawerState.close()
                                navController.navigate(item.route) {
                                    launchSingleTop = true
                                    restoreState = true
                                    popUpTo(AppRoute.User.Dashboard) {
                                        saveState = true
                                    }
                                }
                            }
                        },
                        modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp)
                    )
                }
            }
        }
    ) {
        @Composable
        fun DashboardContent() {
            Scaffold(
                topBar = {
                    TopAppBar(
                        title = {
                            if (showSearch) {
                                TextField(
                                    value = "",
                                    onValueChange = { },
                                    modifier = Modifier.fillMaxWidth(),
                                    placeholder = { Text("Search rides, payments, or bikes") },
                                    singleLine = true,
                                    colors = TextFieldDefaults.colors(
                                        focusedContainerColor = Color.Transparent,
                                        unfocusedContainerColor = Color.Transparent,
                                        focusedIndicatorColor = Color.Black,
                                        unfocusedIndicatorColor = Color.Black
                                    )
                                )
                            } else {
                                Text("Ride Ease")
                            }
                        },
                        navigationIcon = {
                            IconButton(onClick = { scope.launch { drawerState.open() } }) {
                                Icon(Icons.Default.Menu, contentDescription = "Menu")
                            }
                        },
                        actions = {
                            IconButton(onClick = { showSearch = !showSearch }) {
                                Icon(
                                    if (showSearch) Icons.Default.Close else Icons.Default.Search,
                                    contentDescription = if (showSearch) "Close Search" else "Search"
                                )
                            }
                        },
                        colors = TopAppBarDefaults.topAppBarColors(
                            containerColor = Color(0xFFFFEB3B),
                            titleContentColor = Color.Black,
                            navigationIconContentColor = Color.Black,
                            actionIconContentColor = Color.Black
                        )
                    )
                },
                bottomBar = {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(Color.Black)
                            .padding(12.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceEvenly,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            // Payment (Left)
                            Column(
                                horizontalAlignment = Alignment.CenterHorizontally,
                                modifier = Modifier
                                    .weight(1f)
                                    .clickable(
                                        interactionSource = remember { MutableInteractionSource() },
                                        indication = rememberRipple(bounded = true, color = Color.White)
                                    ) {
                                        selectedItem = 0
                                        navController.navigate(AppRoute.User.Payment) {
                                            launchSingleTop = true
                                            restoreState = true
                                            popUpTo(AppRoute.User.Dashboard) {
                                                saveState = true
                                            }
                                        }
                                    }
                            ) {
                                Icon(
                                    Icons.Default.Payment,
                                    contentDescription = "Payment",
                                    tint = Color.White,
                                    modifier = Modifier.size(24.dp)
                                )
                                Text(
                                    "Payment",
                                    color = Color.White,
                                    style = MaterialTheme.typography.labelSmall
                                )
                            }

                            // Ride Now (Center)
                            Box(
                                modifier = Modifier.weight(1f),
                                contentAlignment = Alignment.Center
                            ) {
                                Button(
                                    onClick = {
                                        selectedItem = 1
                                        navController.navigate(AppRoute.User.RideNow) {
                                            launchSingleTop = true
                                            restoreState = true
                                            popUpTo(AppRoute.User.Dashboard) {
                                                saveState = true
                                            }
                                        }
                                    },
                                    colors = ButtonDefaults.buttonColors(
                                        containerColor = Color(0xFFFFEB3B),
                                        contentColor = Color.Black
                                    ),
                                    shape = RoundedCornerShape(16.dp),
                                    modifier = Modifier
                                        .size(64.dp)
                                        .offset(y = (-20).dp)
                                ) {
                                    Icon(
                                        Icons.Default.DirectionsBike,
                                        contentDescription = "Ride Now",
                                        modifier = Modifier.size(32.dp)
                                    )
                                }
                            }

                            // Fare Estimate (Right)
                            Column(
                                horizontalAlignment = Alignment.CenterHorizontally,
                                modifier = Modifier
                                    .weight(1f)
                                    .clickable(
                                        interactionSource = remember { MutableInteractionSource() },
                                        indication = rememberRipple(bounded = true, color = Color.White)
                                    ) {
                                        selectedItem = 2
                                        navController.navigate(AppRoute.User.FareEstimate) {
                                            launchSingleTop = true
                                            restoreState = true
                                            popUpTo(AppRoute.User.Dashboard) {
                                                saveState = true
                                            }
                                        }
                                    }
                            ) {
                                Icon(
                                    Icons.Default.Calculate,
                                    contentDescription = "Fare Estimate",
                                    tint = Color.White,
                                    modifier = Modifier.size(24.dp)
                                )
                                Text(
                                    "Fare Estimate",
                                    color = Color.White,
                                    style = MaterialTheme.typography.labelSmall
                                )
                            }
                        }
                    }
                }
            ) { paddingValues ->
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(paddingValues)
                ) {
                    Image(
                        painter = painterResource(id = R.drawable.bcg),
                        contentDescription = "Dashboard Background",
                        modifier = Modifier.fillMaxSize(),
                        contentScale = ContentScale.Fit
                    )
                    Image(
                        painter = painterResource(id = R.drawable.bcg),
                        contentDescription = "Cyclist Route",
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(32.dp),
                        contentScale = ContentScale.Fit
                    )
                }
            }
        }
        DashboardContent()
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun CycleCard(
    cycle: Cycle,
    onCycleClick: () -> Unit
) {
    Card(
        onClick = onCycleClick,
        modifier = Modifier
            .fillMaxWidth()
            .height(100.dp)
            .padding(horizontal = 16.dp, vertical = 8.dp),
        enabled = cycle.isAvailable,
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.surface,
            disabledContainerColor = MaterialTheme.colorScheme.surfaceVariant
        ),
        elevation = CardDefaults.cardElevation(
            defaultElevation = 2.dp,
            pressedElevation = 8.dp,
            disabledElevation = 0.dp
        )
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(8.dp)
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                // Left section with bike image
                Box(
                    modifier = Modifier
                        .size(80.dp)
                        .background(
                            color = MaterialTheme.colorScheme.primaryContainer,
                            shape = MaterialTheme.shapes.small
                        ),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Filled.DirectionsBike,
                        contentDescription = "Bike",
                        modifier = Modifier.size(40.dp),
                        tint = MaterialTheme.colorScheme.onPrimaryContainer
                    )
                }

                // Middle section with bike details
                Column(
                    modifier = Modifier
                        .weight(1f)
                        .padding(horizontal = 12.dp),
                    verticalArrangement = Arrangement.Center
                ) {
                    Text(
                        text = "Bike Number: ${cycle.id}",
                        style = MaterialTheme.typography.titleMedium,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = "${cycle.distanceRange} km",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }

                // Right section with battery indicator
                Column(
                    horizontalAlignment = Alignment.End,
                    verticalArrangement = Arrangement.Center
                ) {
                    Text(
                        text = "${cycle.batteryPercentage}%",
                        style = MaterialTheme.typography.titleMedium,
                        color = if (cycle.batteryPercentage > 20)
                            MaterialTheme.colorScheme.primary
                        else MaterialTheme.colorScheme.error
                    )
                    Icon(
                        imageVector = Icons.Default.BatteryFull,
                        contentDescription = "Battery",
                        tint = if (cycle.batteryPercentage > 20)
                            MaterialTheme.colorScheme.primary
                        else MaterialTheme.colorScheme.error,
                        modifier = Modifier.size(24.dp)
                    )
                }

                if (!cycle.isAvailable) {
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = "Currently In Use",
                        color = MaterialTheme.colorScheme.error,
                        style = MaterialTheme.typography.bodySmall
                    )
                }
            }
        }
    }
}