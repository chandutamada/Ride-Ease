package com.cutm.rideease.screens.manager

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.background
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import java.text.NumberFormat
import java.util.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun RevenueDashboardScreen(navController: NavController) {
    val currencyFormat = remember { NumberFormat.getCurrencyInstance(Locale("en", "IN")) }
    
    var revenueData by remember {
        mutableStateOf(mapOf(
            "totalRevenue" to 254800.0,
            "paymentMethods" to mapOf<String, Double>(
                "UPI" to 65.0,
                "Credit Card" to 25.0,
                "Cash" to 10.0
            ),
            "dailyTrends" to listOf<Double>(12000.0, 15000.0, 18000.0, 21000.0, 19500.0)
        ))
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Revenue Dashboard") },
                navigationIcon = {
                    IconButton(onClick = { navController.popBackStack() }) {
                        Icon(Icons.Default.ArrowBack, "Back")
                    }
                },
                actions = {
                    IconButton(onClick = { /* Export data */ }) {
                        Icon(Icons.Default.Download, "Export")
                    }
                }
            )
        }
    ) { padding ->
        LazyColumn(
            modifier = Modifier
                .padding(padding)
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(24.dp)
        ) {
            item {
                RevenueSummaryCard(
                    totalRevenue = (revenueData["totalRevenue"] as? Double) ?: 0.0,
                    currencyFormat = currencyFormat
                )
            }
            
            item {
                PaymentMethodBreakdown(
                    paymentMethods = (revenueData["paymentMethods"] as? Map<String, Double>) ?: emptyMap(),
                    currencyFormat = currencyFormat
                )
            }
            
            item {
                DailyRevenueTrend(
                    trends = revenueData["dailyTrends"] as List<Double>,
                    currencyFormat = currencyFormat
                )
            }
        }
    }
}

@Composable
private fun RevenueSummaryCard(totalRevenue: Double, currencyFormat: NumberFormat) {
    Card(
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(
            modifier = Modifier.padding(16.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(
                text = "Total Revenue",
                style = MaterialTheme.typography.bodyLarge,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            Spacer(modifier = Modifier.height(8.dp))
            Text(
                text = currencyFormat.format(totalRevenue),
                style = MaterialTheme.typography.displaySmall,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.primary
            )
            Spacer(modifier = Modifier.height(8.dp))
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                MetricItem("Today", 18500.0, currencyFormat)
                MetricItem("This Week", 98500.0, currencyFormat)
                MetricItem("Monthly", 254800.0, currencyFormat)
            }
        }
    }
}

@Composable
private fun PaymentMethodBreakdown(paymentMethods: Map<String, Double>, currencyFormat: NumberFormat) {
    Card(
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(
            modifier = Modifier.padding(16.dp)
        ) {
            Text(
                text = "Payment Methods",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold
            )
            Spacer(modifier = Modifier.height(16.dp))
            paymentMethods.forEach { (method, percentage) ->
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text(text = method)
                    Text(
                        text = "${percentage}%",
                        color = MaterialTheme.colorScheme.primary,
                        fontWeight = FontWeight.Bold
                    )
                }
                Spacer(modifier = Modifier.height(8.dp))
            }
        }
    }
}

@Composable
private fun DailyRevenueTrend(trends: List<Double>, currencyFormat: NumberFormat) {
    Card(
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(
            modifier = Modifier.padding(16.dp)
        ) {
            Text(
                text = "Weekly Trend",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold
            )
            Spacer(modifier = Modifier.height(16.dp))
            // Placeholder for chart implementation
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(200.dp)
                    .background(Color.LightGray.copy(alpha = 0.2f))
                    .padding(16.dp),
                contentAlignment = Alignment.Center
            ) {
                Text("Revenue Chart Implementation")
            }
        }
    }
}

@Composable
private fun MetricItem(label: String, value: Double, currencyFormat: NumberFormat) {
    Column(
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text(
            text = label,
            style = MaterialTheme.typography.labelSmall
        )
        Text(
            text = currencyFormat.format(value),
            style = MaterialTheme.typography.bodyLarge
        )
    }
}