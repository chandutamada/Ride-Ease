package com.cutm.rideease.screens.user

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material.icons.filled.VisibilityOff
import androidx.compose.material.icons.filled.PhotoCamera
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import com.cutm.rideease.data.UserDataManager
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.Image
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import coil.compose.rememberAsyncImagePainter
import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ProfileScreen(navController: NavController) {
    val context = LocalContext.current
    val userDataManager = remember { UserDataManager.getInstance(context) }
    
    // Get current user data
    val currentName = remember { userDataManager.getUserName() }
    val currentEmail = remember { userDataManager.getUserEmail() }
    val currentAge = remember { userDataManager.getUserAge() }
    val currentGender = remember { userDataManager.getUserGender() }
    val currentPhone = remember { userDataManager.getUserPhone() }
    val currentProfilePic = remember { userDataManager.getUserProfilePicture() }
    
    // State for form fields
    var name by remember { mutableStateOf(currentName) }
    var age by remember { mutableStateOf(if (currentAge > 0) currentAge.toString() else "") }
    var gender by remember { mutableStateOf(currentGender) }
    var phone by remember { mutableStateOf(currentPhone) }
    var profilePicUri by remember { mutableStateOf(if (currentProfilePic.isNotEmpty()) Uri.parse(currentProfilePic) else null) }
    var currentPassword by remember { mutableStateOf("") }
    var newPassword by remember { mutableStateOf("") }
    var confirmPassword by remember { mutableStateOf("") }
    
    // State for password visibility
    var currentPasswordVisible by remember { mutableStateOf(false) }
    var newPasswordVisible by remember { mutableStateOf(false) }
    var confirmPasswordVisible by remember { mutableStateOf(false) }
    
    // State for validation errors
    var nameError by remember { mutableStateOf("") }
    var ageError by remember { mutableStateOf("") }
    var genderError by remember { mutableStateOf("") }
    var phoneError by remember { mutableStateOf("") }
    var currentPasswordError by remember { mutableStateOf("") }
    var newPasswordError by remember { mutableStateOf("") }
    var confirmPasswordError by remember { mutableStateOf("") }
    
    // State for success message
    var showSuccessMessage by remember { mutableStateOf(false) }
    var successMessage by remember { mutableStateOf("") }
    
    // Gender options
    val genderOptions = listOf("Male", "Female", "Other")
    var expandedGenderMenu by remember { mutableStateOf(false) }
    
    // Image picker launcher
    val imagePickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.GetContent()
    ) { uri: Uri? ->
        uri?.let {
            profilePicUri = it
            userDataManager.updateUserProfilePicture(it.toString())
        }
    }
    
    // Check if profile is complete
    val isProfileComplete = remember(age, gender, phone) {
        age.isNotBlank() && gender.isNotBlank() && phone.isNotBlank()
    }
    
    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Update Profile") },
                navigationIcon = {
                    IconButton(onClick = { navController.navigateUp() }) {
                        Icon(Icons.Default.ArrowBack, contentDescription = "Back")
                    }
                }
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(horizontal = 24.dp)
                .verticalScroll(rememberScrollState()),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            Spacer(modifier = Modifier.height(16.dp))
            
            // Profile Picture
            Box(
                modifier = Modifier
                    .size(120.dp)
                    .clip(CircleShape)
                    .border(2.dp, MaterialTheme.colorScheme.primary, CircleShape)
                    .clickable { imagePickerLauncher.launch("image/*") },
                contentAlignment = Alignment.Center
            ) {
                if (profilePicUri != null) {
                    Image(
                        painter = rememberAsyncImagePainter(profilePicUri),
                        contentDescription = "Profile Picture",
                        modifier = Modifier.fillMaxSize(),
                        contentScale = ContentScale.Crop
                    )
                } else {
                    Icon(
                        imageVector = Icons.Default.PhotoCamera,
                        contentDescription = "Add Profile Picture",
                        modifier = Modifier.size(40.dp),
                        tint = MaterialTheme.colorScheme.primary
                    )
                }
            }
            
            Text(
                text = "Tap to change profile picture",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.primary
            )
            
            // Display email (non-editable)
            OutlinedTextField(
                value = currentEmail,
                onValueChange = { },
                label = { Text("Email") },
                readOnly = true,
                enabled = false,
                modifier = Modifier.fillMaxWidth()
            )
            
            // Name field
            OutlinedTextField(
                value = name,
                onValueChange = { 
                    name = it
                    nameError = ""
                },
                label = { Text("Name") },
                singleLine = true,
                isError = nameError.isNotEmpty(),
                supportingText = { if (nameError.isNotEmpty()) Text(nameError) },
                modifier = Modifier.fillMaxWidth(),
                keyboardOptions = KeyboardOptions(
                    imeAction = ImeAction.Next
                )
            )
            
            // Age field
            OutlinedTextField(
                value = age,
                onValueChange = { 
                    if (it.isEmpty() || it.all { char -> char.isDigit() }) {
                        age = it
                        ageError = ""
                    }
                },
                label = { Text("Age") },
                singleLine = true,
                isError = ageError.isNotEmpty(),
                supportingText = { if (ageError.isNotEmpty()) Text(ageError) },
                modifier = Modifier.fillMaxWidth(),
                keyboardOptions = KeyboardOptions(
                    keyboardType = KeyboardType.Number,
                    imeAction = ImeAction.Next
                )
            )
            
            // Gender field (dropdown)
            ExposedDropdownMenuBox(
                expanded = expandedGenderMenu,
                onExpandedChange = { expandedGenderMenu = it },
                modifier = Modifier.fillMaxWidth()
            ) {
                OutlinedTextField(
                    value = gender,
                    onValueChange = {},
                    readOnly = true,
                    label = { Text("Gender") },
                    trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = expandedGenderMenu) },
                    isError = genderError.isNotEmpty(),
                    supportingText = { if (genderError.isNotEmpty()) Text(genderError) },
                    modifier = Modifier.menuAnchor().fillMaxWidth(),
                )
                
                ExposedDropdownMenu(
                    expanded = expandedGenderMenu,
                    onDismissRequest = { expandedGenderMenu = false }
                ) {
                    genderOptions.forEach { option ->
                        DropdownMenuItem(
                            text = { Text(option) },
                            onClick = {
                                gender = option
                                genderError = ""
                                expandedGenderMenu = false
                            }
                        )
                    }
                }
            }
            
            // Phone field
            OutlinedTextField(
                value = phone,
                onValueChange = { 
                    if (it.isEmpty() || it.all { char -> char.isDigit() }) {
                        phone = it
                        phoneError = ""
                    }
                },
                label = { Text("Phone Number") },
                singleLine = true,
                isError = phoneError.isNotEmpty(),
                supportingText = { if (phoneError.isNotEmpty()) Text(phoneError) },
                modifier = Modifier.fillMaxWidth(),
                keyboardOptions = KeyboardOptions(
                    keyboardType = KeyboardType.Phone,
                    imeAction = ImeAction.Next
                )
            )
            
            // Profile completion status
            if (!isProfileComplete) {
                Card(
                    colors = CardDefaults.cardColors(
                        containerColor = MaterialTheme.colorScheme.errorContainer
                    ),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text(
                        text = "Please complete your profile by filling all required fields",
                        modifier = Modifier.padding(16.dp),
                        color = MaterialTheme.colorScheme.onErrorContainer
                    )
                }
            }
            
            Divider(modifier = Modifier.padding(vertical = 8.dp))
            
            Text(
                text = "Change Password",
                style = MaterialTheme.typography.titleMedium,
                modifier = Modifier.align(Alignment.Start)
            )
            
            // Current password field
            OutlinedTextField(
                value = currentPassword,
                onValueChange = { 
                    currentPassword = it 
                    currentPasswordError = ""
                },
                label = { Text("Current Password") },
                singleLine = true,
                isError = currentPasswordError.isNotEmpty(),
                supportingText = { if (currentPasswordError.isNotEmpty()) Text(currentPasswordError) },
                visualTransformation = if (currentPasswordVisible) VisualTransformation.None else PasswordVisualTransformation(),
                keyboardOptions = KeyboardOptions(
                    keyboardType = KeyboardType.Password,
                    imeAction = ImeAction.Next
                ),
                trailingIcon = {
                    IconButton(onClick = { currentPasswordVisible = !currentPasswordVisible }) {
                        Icon(
                            imageVector = if (currentPasswordVisible) Icons.Default.VisibilityOff else Icons.Default.Visibility,
                            contentDescription = if (currentPasswordVisible) "Hide password" else "Show password"
                        )
                    }
                },
                modifier = Modifier.fillMaxWidth()
            )
            
            // New password field
            OutlinedTextField(
                value = newPassword,
                onValueChange = { 
                    newPassword = it 
                    newPasswordError = ""
                    if (confirmPassword.isNotEmpty() && it != confirmPassword) {
                        confirmPasswordError = "Passwords don't match"
                    } else {
                        confirmPasswordError = ""
                    }
                },
                label = { Text("New Password") },
                singleLine = true,
                isError = newPasswordError.isNotEmpty(),
                supportingText = { if (newPasswordError.isNotEmpty()) Text(newPasswordError) },
                visualTransformation = if (newPasswordVisible) VisualTransformation.None else PasswordVisualTransformation(),
                keyboardOptions = KeyboardOptions(
                    keyboardType = KeyboardType.Password,
                    imeAction = ImeAction.Next
                ),
                trailingIcon = {
                    IconButton(onClick = { newPasswordVisible = !newPasswordVisible }) {
                        Icon(
                            imageVector = if (newPasswordVisible) Icons.Default.VisibilityOff else Icons.Default.Visibility,
                            contentDescription = if (newPasswordVisible) "Hide password" else "Show password"
                        )
                    }
                },
                modifier = Modifier.fillMaxWidth()
            )
            
            // Confirm password field
            OutlinedTextField(
                value = confirmPassword,
                onValueChange = { 
                    confirmPassword = it 
                    confirmPasswordError = if (it != newPassword) "Passwords don't match" else ""
                },
                label = { Text("Confirm New Password") },
                singleLine = true,
                isError = confirmPasswordError.isNotEmpty(),
                supportingText = { if (confirmPasswordError.isNotEmpty()) Text(confirmPasswordError) },
                visualTransformation = if (confirmPasswordVisible) VisualTransformation.None else PasswordVisualTransformation(),
                keyboardOptions = KeyboardOptions(
                    keyboardType = KeyboardType.Password,
                    imeAction = ImeAction.Done
                ),
                trailingIcon = {
                    IconButton(onClick = { confirmPasswordVisible = !confirmPasswordVisible }) {
                        Icon(
                            imageVector = if (confirmPasswordVisible) Icons.Default.VisibilityOff else Icons.Default.Visibility,
                            contentDescription = if (confirmPasswordVisible) "Hide password" else "Show password"
                        )
                    }
                },
                modifier = Modifier.fillMaxWidth()
            )
            
            Spacer(modifier = Modifier.height(8.dp))
            
            // Success message
            AnimatedVisibility(
                visible = showSuccessMessage,
                modifier = Modifier.fillMaxWidth()
            ) {
                Card(
                    colors = CardDefaults.cardColors(
                        containerColor = MaterialTheme.colorScheme.primaryContainer
                    ),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text(
                        text = successMessage,
                        modifier = Modifier.padding(16.dp),
                        color = MaterialTheme.colorScheme.onPrimaryContainer
                    )
                }
            }
            
            Spacer(modifier = Modifier.weight(1f))
            
            // Update profile button
            Button(
                onClick = {
                    // Validate profile fields
                    var hasError = false
                    
                    if (name.isBlank()) {
                        nameError = "Name cannot be empty"
                        hasError = true
                    }
                    
                    if (age.isBlank()) {
                        ageError = "Age is required"
                        hasError = true
                    } else if (age.toIntOrNull() == null || age.toInt() <= 0 || age.toInt() > 120) {
                        ageError = "Please enter a valid age"
                        hasError = true
                    }
                    
                    if (gender.isBlank()) {
                        genderError = "Gender is required"
                        hasError = true
                    }
                    
                    if (phone.isBlank()) {
                        phoneError = "Phone number is required"
                        hasError = true
                    } else if (phone.length < 10) {
                        phoneError = "Please enter a valid phone number"
                        hasError = true
                    }
                    
                    if (!hasError) {
                        // Update user profile
                        userDataManager.updateUserName(name)
                        userDataManager.updateUserAge(age.toInt())
                        userDataManager.updateUserGender(gender)
                        userDataManager.updateUserPhone(phone)
                        
                        showSuccessMessage = true
                        successMessage = "Profile updated successfully"
                    }
                },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(50.dp),
                enabled = name.isNotBlank()
            ) {
                Text("Update Profile")
            }
            
            Spacer(modifier = Modifier.height(16.dp))
            
            // Update password button
            Button(
                onClick = {
                    // Validate password fields
                    var hasError = false
                    
                    if (currentPassword.isBlank()) {
                        currentPasswordError = "Current password is required"
                        hasError = true
                    } else if (currentPassword != userDataManager.getUserPassword() && 
                              userDataManager.getUserPassword().isNotEmpty()) {
                        currentPasswordError = "Current password is incorrect"
                        hasError = true
                    }
                    
                    if (newPassword.isBlank()) {
                        newPasswordError = "New password is required"
                        hasError = true
                    } else if (newPassword.length < 6) {
                        newPasswordError = "Password must be at least 6 characters"
                        hasError = true
                    }
                    
                    if (confirmPassword.isBlank()) {
                        confirmPasswordError = "Please confirm your password"
                        hasError = true
                    } else if (confirmPassword != newPassword) {
                        confirmPasswordError = "Passwords don't match"
                        hasError = true
                    }
                    
                    if (!hasError) {
                        userDataManager.updateUserPassword(newPassword)
                        currentPassword = ""
                        newPassword = ""
                        confirmPassword = ""
                        showSuccessMessage = true
                        successMessage = "Password updated successfully"
                    }
                },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(50.dp),
                enabled = currentPassword.isNotBlank() && newPassword.isNotBlank() && confirmPassword.isNotBlank()
            ) {
                Text("Update Password")
            }
            
            Spacer(modifier = Modifier.height(24.dp))
        }
    }
}