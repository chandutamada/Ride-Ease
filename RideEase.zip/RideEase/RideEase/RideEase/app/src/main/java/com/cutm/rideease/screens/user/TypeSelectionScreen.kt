package com.cutm.rideease.screens.user

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import com.cutm.rideease.navigation.AppRoute

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun TypeSelectionScreen(navController: NavController) {
    val categories = listOf("Mountain E-Bike", "City Cruiser", "Sport E-Bike", "Comfort Rider")
    
    Scaffold(
        topBar = {
            TopAppBar(title = { Text("Select Cycle Type") })
        }
    ) { padding ->
        LazyVerticalGrid(
            columns = GridCells.Fixed(2),
            modifier = Modifier.padding(padding),
            verticalArrangement = Arrangement.spacedBy(16.dp),
            horizontalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            items(categories) { type ->
                Card(
                    onClick = { navController.navigate("${AppRoute.User.CycleList}/$type") },
                    modifier = Modifier.height(150.dp)
                ) {
                    Box(
                        modifier = Modifier.fillMaxSize(),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(text = type, style = MaterialTheme.typography.titleMedium)
                    }
                }
            }
        }
    }
}