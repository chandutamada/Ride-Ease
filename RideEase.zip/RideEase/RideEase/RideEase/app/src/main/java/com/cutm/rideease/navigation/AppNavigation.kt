package com.cutm.rideease.navigation

import androidx.compose.runtime.Composable
import androidx.navigation.NavHostController
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import com.cutm.rideease.screens.auth.AuthScreen
import com.cutm.rideease.screens.employee.EmployeeDashboardScreen
import com.cutm.rideease.screens.employee.FeedbackReviewScreen
import com.cutm.rideease.screens.employee.MaintenanceListScreen
import com.cutm.rideease.screens.employee.PaymentConfirmationScreen
import com.cutm.rideease.screens.manager.ManagerDashboardScreen
import com.cutm.rideease.screens.manager.RevenueDashboardScreen
import com.cutm.rideease.screens.manager.RideAnalyticsScreen
import com.cutm.rideease.screens.manager.UserManagementScreen
import com.cutm.rideease.screens.manager.MaintenanceTrackingScreen
import com.cutm.rideease.screens.manager.FeedbackSystemScreen
import com.cutm.rideease.screens.manager.SettingsScreen
import com.cutm.rideease.screens.user.FareEstimateScreen
import com.cutm.rideease.screens.user.PaymentScreen
import com.cutm.rideease.screens.user.QRScannerScreen
import com.cutm.rideease.screens.user.RideNowScreen
import com.cutm.rideease.screens.user.TypeSelectionScreen
import com.cutm.rideease.screens.user.UserDashboardScreen
import com.cutm.rideease.screens.user.CycleListScreen
import com.cutm.rideease.screens.user.ProfileScreen
import com.cutm.rideease.screens.user.HistoryScreen
import com.cutm.rideease.screens.user.FeedbackScreen
import com.cutm.rideease.screens.user.RideTrackingScreen

@Composable
fun AppNavigation(
    navController: NavHostController = rememberNavController(),
    startDestination: String = AppRoute.Auth.Login
) {
    NavHost(
        navController = navController,
        startDestination = startDestination
    ) {
        // Auth routes
        composable(AppRoute.Auth.Login) {
            AuthScreen(navController = navController, isLogin = true)
        }
        composable(AppRoute.Auth.SignUp) {
            AuthScreen(navController = navController, isLogin = false)
        }

        // User routes
        composable(AppRoute.User.Dashboard) {
            UserDashboardScreen(navController = navController)
        }
        composable(AppRoute.User.Profile) {
            ProfileScreen(navController = navController)
        }
        composable(AppRoute.User.History) {
            HistoryScreen(navController = navController)
        }
        composable(AppRoute.User.Feedback) {
            FeedbackScreen(navController = navController)
        }
        composable(AppRoute.User.RideNow) {
            RideNowScreen(navController = navController)
        }
        composable(AppRoute.User.TypeSelection) {
            TypeSelectionScreen(navController = navController)
        }
        composable(AppRoute.User.FareEstimate) {
            FareEstimateScreen(navController = navController)
        }
        composable(AppRoute.User.Payment) {
            PaymentScreen(navController = navController)
        }
        composable(AppRoute.User.QRScanner) {
            QRScannerScreen(navController = navController)
        }
        
        composable(AppRoute.User.RideTracking) {
            RideTrackingScreen(navController = navController)
        }

        composable(
            route = "${AppRoute.User.CycleList}/{type}",
            arguments = listOf(
                navArgument("type") { type = NavType.StringType }
            )
        ) { backStackEntry ->
            val type = backStackEntry.arguments?.getString("type") ?: ""
            CycleListScreen(
                navController = navController,
                type = type
            )
        }

        // Employee routes
        composable(AppRoute.Employee.Dashboard) {
            EmployeeDashboardScreen(navController = navController)
        }
        composable(AppRoute.Employee.PaymentConfirmation) {
            PaymentConfirmationScreen(navController = navController)
        }
        composable(
            route = AppRoute.Employee.MaintenanceList,
            arguments = listOf(
                navArgument("cycleType") { type = NavType.StringType }
            )
        ) { backStackEntry ->
            val cycleType = backStackEntry.arguments?.getString("cycleType") ?: ""
            MaintenanceListScreen(
                navController = navController,
                cycleType = cycleType
            )
        }
        composable(AppRoute.Employee.FeedbackReview) {
            FeedbackReviewScreen(navController = navController)
        }

        // Manager routes
        composable(AppRoute.Manager.Dashboard) {
            ManagerDashboardScreen(navController = navController)
        }
        composable(AppRoute.Manager.Revenue) {
            RevenueDashboardScreen(navController = navController)
        }
        composable(AppRoute.Manager.Analytics) {
            RideAnalyticsScreen(navController = navController)
        }
        composable(AppRoute.Manager.UserManagement) {
            UserManagementScreen(navController = navController)
        }
        composable(AppRoute.Manager.Maintenance) {
            MaintenanceTrackingScreen(navController = navController)
        }
        composable(AppRoute.Manager.FeedbackSystem) {
            FeedbackSystemScreen(navController = navController)
        }
        composable(AppRoute.Manager.Settings) {
            SettingsScreen(navController = navController)
        }
    }
}
