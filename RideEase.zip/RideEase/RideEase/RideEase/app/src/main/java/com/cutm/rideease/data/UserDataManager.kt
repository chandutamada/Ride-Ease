package com.cutm.rideease.data

import android.content.Context
import android.content.SharedPreferences

/**
 * Manages user data persistence using SharedPreferences
 */
class UserDataManager(context: Context) {
    private val sharedPreferences: SharedPreferences = 
        context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE)
    
    /**
     * Saves user information after successful authentication
     */
    fun saveUserInfo(name: String, email: String, role: String) {
        sharedPreferences.edit().apply {
            putString(KEY_USER_NAME, name)
            putString(KEY_USER_EMAIL, email)
            putString(KEY_USER_ROLE, role)
            putBoolean(KEY_IS_LOGGED_IN, true)
            apply()
        }
    }
    
    /**
     * Retrieves the current user's name
     */
    fun getUserName(): String {
        return sharedPreferences.getString(KEY_USER_NAME, "") ?: ""
    }
    
    /**
     * Retrieves the current user's email
     */
    fun getUserEmail(): String {
        return sharedPreferences.getString(KEY_USER_EMAIL, "") ?: ""
    }
    
    /**
     * Retrieves the current user's role
     */
    fun getUserRole(): String {
        return sharedPreferences.getString(KEY_USER_ROLE, "") ?: ""
    }
    
    /**
     * Checks if a user is currently logged in
     */
    fun isLoggedIn(): Boolean {
        return sharedPreferences.getBoolean(KEY_IS_LOGGED_IN, false)
    }
    
    /**
     * Updates the user's name
     */
    fun updateUserName(newName: String) {
        sharedPreferences.edit().apply {
            putString(KEY_USER_NAME, newName)
            apply()
        }
    }
    
    /**
     * Updates the user's password
     * Note: In a real app, you would want to hash passwords
     */
    fun updateUserPassword(newPassword: String) {
        sharedPreferences.edit().apply {
            putString(KEY_USER_PASSWORD, newPassword)
            apply()
        }
    }
    
    /**
     * Gets the user's password
     */
    fun getUserPassword(): String {
        return sharedPreferences.getString(KEY_USER_PASSWORD, "") ?: ""
    }
    
    /**
     * Clears all user data (for logout)
     */
    fun clearUserData() {
        sharedPreferences.edit().clear().apply()
    }
    
    /**
     * Updates the user's age
     */
    fun updateUserAge(age: Int) {
        sharedPreferences.edit().apply {
            putInt(KEY_USER_AGE, age)
            apply()
        }
    }
    
    /**
     * Gets the user's age
     */
    fun getUserAge(): Int {
        return sharedPreferences.getInt(KEY_USER_AGE, 0)
    }
    
    /**
     * Updates the user's gender
     */
    fun updateUserGender(gender: String) {
        sharedPreferences.edit().apply {
            putString(KEY_USER_GENDER, gender)
            apply()
        }
    }
    
    /**
     * Gets the user's gender
     */
    fun getUserGender(): String {
        return sharedPreferences.getString(KEY_USER_GENDER, "") ?: ""
    }
    
    /**
     * Updates the user's phone number
     */
    fun updateUserPhone(phone: String) {
        sharedPreferences.edit().apply {
            putString(KEY_USER_PHONE, phone)
            apply()
        }
    }
    
    /**
     * Gets the user's phone number
     */
    fun getUserPhone(): String {
        return sharedPreferences.getString(KEY_USER_PHONE, "") ?: ""
    }
    
    /**
     * Updates the user's profile picture URI
     */
    fun updateUserProfilePicture(uri: String) {
        sharedPreferences.edit().apply {
            putString(KEY_USER_PROFILE_PIC, uri)
            apply()
        }
    }
    
    /**
     * Gets the user's profile picture URI
     */
    fun getUserProfilePicture(): String {
        return sharedPreferences.getString(KEY_USER_PROFILE_PIC, "") ?: ""
    }
    
    /**
     * Checks if the user has completed their profile
     */
    fun isProfileComplete(): Boolean {
        val hasAge = getUserAge() > 0
        val hasGender = getUserGender().isNotEmpty()
        val hasPhone = getUserPhone().isNotEmpty()
        
        return hasAge && hasGender && hasPhone
    }
    
    companion object {
        private const val PREF_NAME = "ride_ease_user_prefs"
        private const val KEY_USER_NAME = "user_name"
        private const val KEY_USER_EMAIL = "user_email"
        private const val KEY_USER_ROLE = "user_role"
        private const val KEY_IS_LOGGED_IN = "is_logged_in"
        private const val KEY_USER_PASSWORD = "user_password"
        private const val KEY_USER_AGE = "user_age"
        private const val KEY_USER_GENDER = "user_gender"
        private const val KEY_USER_PHONE = "user_phone"
        private const val KEY_USER_PROFILE_PIC = "user_profile_pic"
        
        // Singleton instance
        @Volatile
        private var INSTANCE: UserDataManager? = null
        
        fun getInstance(context: Context): UserDataManager {
            return INSTANCE ?: synchronized(this) {
                INSTANCE ?: UserDataManager(context.applicationContext).also { INSTANCE = it }
            }
        }
    }
}