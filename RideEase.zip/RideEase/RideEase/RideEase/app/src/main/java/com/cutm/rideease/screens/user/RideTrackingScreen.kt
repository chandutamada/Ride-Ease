package com.cutm.rideease.screens.user

import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Stop
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import kotlinx.coroutines.delay
import java.time.Duration
import java.time.LocalDateTime

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun RideTrackingScreen(
    navController: NavController,
    modifier: Modifier = Modifier
) {
    var startTime by remember { mutableStateOf(LocalDateTime.now()) }
    var elapsedTime by remember { mutableStateOf(Duration.ZERO) }
    var distance by remember { mutableStateOf(0.0) } // In kilometers
    
    LaunchedEffect(startTime) {
        while (true) {
            delay(1000) // Update every second
            elapsedTime = Duration.between(startTime, LocalDateTime.now())
            // In a real app, you would update distance based on GPS data
            distance += 0.001 // Simulated distance increase
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Ride in Progress") },
                navigationIcon = {
                    IconButton(onClick = { navController.navigateUp() }) {
                        Icon(Icons.Default.ArrowBack, contentDescription = "Back")
                    }
                }
            )
        }
    ) { padding ->
        Column(
            modifier = modifier
                .fillMaxSize()
                .padding(padding)
                .padding(16.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(24.dp)
        ) {
            // Ride Stats
            Card(
                modifier = Modifier.fillMaxWidth(),
            ) {
                Column(
                    modifier = Modifier
                        .padding(16.dp)
                        .fillMaxWidth(),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.spacedBy(16.dp)
                ) {
                    // Duration
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text(
                            text = "Duration",
                            style = MaterialTheme.typography.titleMedium
                        )
                        Text(
                            text = String.format(
                                "%02d:%02d:%02d",
                                elapsedTime.toHours(),
                                elapsedTime.toMinutesPart(),
                                elapsedTime.toSecondsPart()
                            ),
                            style = MaterialTheme.typography.headlineMedium
                        )
                    }
                    
                    Divider()
                    
                    // Distance
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text(
                            text = "Distance",
                            style = MaterialTheme.typography.titleMedium
                        )
                        Text(
                            text = String.format("%.2f km", distance),
                            style = MaterialTheme.typography.headlineMedium
                        )
                    }
                }
            }
            
            Spacer(modifier = Modifier.weight(1f))
            
            // End Ride Button
            Button(
                onClick = {
                    // In a real app, you would save ride data here
                    navController.navigate(com.cutm.rideease.navigation.AppRoute.User.Dashboard) {
                        popUpTo(com.cutm.rideease.navigation.AppRoute.User.RideTracking) { inclusive = true }
                    }
                },
                modifier = Modifier.fillMaxWidth(),
                colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.error)
            ) {
                Icon(Icons.Default.Stop, contentDescription = "End Ride")
                Spacer(modifier = Modifier.width(8.dp))
                Text("End Ride")
            }
        }
    }
}