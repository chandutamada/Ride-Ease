package com.cutm.rideease.screens.manager

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SettingsScreen(navController: NavController) {
    var darkModeEnabled by remember { mutableStateOf(false) }
    var notificationsEnabled by remember { mutableStateOf(true) }
    var dataBackupEnabled by remember { mutableStateOf(false) }
    var autoLogoutEnabled by remember { mutableStateOf(true) }
    var showConfirmDialog by remember { mutableStateOf(false) }
    var dialogTitle by remember { mutableStateOf("") }
    var dialogMessage by remember { mutableStateOf("") }
    var dialogAction by remember { mutableStateOf({}) }
    
    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Settings") },
                navigationIcon = {
                    IconButton(onClick = { navController.popBackStack() }) {
                        Icon(Icons.Default.ArrowBack, contentDescription = "Back")
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = Color(0xFFECDD6E),
                    titleContentColor = Color.Black,
                    navigationIconContentColor = Color.Black,
                    actionIconContentColor = Color.Black
                )
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(16.dp)
                .verticalScroll(rememberScrollState())
        ) {
            Text(
                text = "General Settings",
                style = MaterialTheme.typography.titleLarge,
                fontWeight = FontWeight.Bold,
                modifier = Modifier.padding(vertical = 16.dp)
            )
            
            SettingsSwitchItem(
                title = "Dark Mode",
                description = "Enable dark theme for the application",
                icon = Icons.Default.DarkMode,
                checked = darkModeEnabled,
                onCheckedChange = { darkModeEnabled = it }
            )
            
            Divider(modifier = Modifier.padding(vertical = 8.dp))
            
            SettingsSwitchItem(
                title = "Notifications",
                description = "Enable push notifications",
                icon = Icons.Default.Notifications,
                checked = notificationsEnabled,
                onCheckedChange = { notificationsEnabled = it }
            )
            
            Divider(modifier = Modifier.padding(vertical = 8.dp))
            
            SettingsSwitchItem(
                title = "Automatic Data Backup",
                description = "Backup data to cloud storage daily",
                icon = Icons.Default.Backup,
                checked = dataBackupEnabled,
                onCheckedChange = { dataBackupEnabled = it }
            )
            
            Divider(modifier = Modifier.padding(vertical = 8.dp))
            
            SettingsSwitchItem(
                title = "Auto Logout",
                description = "Automatically logout after 30 minutes of inactivity",
                icon = Icons.Default.ExitToApp,
                checked = autoLogoutEnabled,
                onCheckedChange = { autoLogoutEnabled = it }
            )
            
            Divider(modifier = Modifier.padding(vertical = 8.dp))
            
            Text(
                text = "System Settings",
                style = MaterialTheme.typography.titleLarge,
                fontWeight = FontWeight.Bold,
                modifier = Modifier.padding(vertical = 16.dp)
            )
            
            SettingsClickableItem(
                title = "Manage Permissions",
                description = "Configure application permissions",
                icon = Icons.Default.Security,
                onClick = {
                    dialogTitle = "Manage Permissions"
                    dialogMessage = "This will open system settings to manage application permissions."
                    dialogAction = {}
                    showConfirmDialog = true
                }
            )
            
            Divider(modifier = Modifier.padding(vertical = 8.dp))
            
            SettingsClickableItem(
                title = "Clear Application Cache",
                description = "Free up space by clearing cached data",
                icon = Icons.Default.DeleteSweep,
                onClick = {
                    dialogTitle = "Clear Cache"
                    dialogMessage = "Are you sure you want to clear all cached data? This action cannot be undone."
                    dialogAction = {}
                    showConfirmDialog = true
                }
            )
            
            Divider(modifier = Modifier.padding(vertical = 8.dp))
            
            SettingsClickableItem(
                title = "System Updates",
                description = "Check for system updates",
                icon = Icons.Default.Update,
                onClick = {
                    dialogTitle = "Check for Updates"
                    dialogMessage = "Checking for system updates..."
                    dialogAction = {}
                    showConfirmDialog = true
                }
            )
            
            Divider(modifier = Modifier.padding(vertical = 8.dp))
            
            Text(
                text = "Account Settings",
                style = MaterialTheme.typography.titleLarge,
                fontWeight = FontWeight.Bold,
                modifier = Modifier.padding(vertical = 16.dp)
            )
            
            SettingsClickableItem(
                title = "Change Password",
                description = "Update your account password",
                icon = Icons.Default.Lock,
                onClick = {
                    dialogTitle = "Change Password"
                    dialogMessage = "This will redirect you to the password change screen."
                    dialogAction = {}
                    showConfirmDialog = true
                }
            )
            
            Divider(modifier = Modifier.padding(vertical = 8.dp))
            
            SettingsClickableItem(
                title = "Manage Profile",
                description = "Update your profile information",
                icon = Icons.Default.Person,
                onClick = {
                    dialogTitle = "Manage Profile"
                    dialogMessage = "This will redirect you to the profile management screen."
                    dialogAction = {}
                    showConfirmDialog = true
                }
            )
            
            Divider(modifier = Modifier.padding(vertical = 8.dp))
            
            SettingsClickableItem(
                title = "Logout",
                description = "Sign out from your account",
                icon = Icons.Default.Logout,
                onClick = {
                    dialogTitle = "Logout"
                    dialogMessage = "Are you sure you want to logout?"
                    dialogAction = {
                        navController.navigate("auth/login") {
                            popUpTo(0) { inclusive = true }
                        }
                    }
                    showConfirmDialog = true
                }
            )
            
            Spacer(modifier = Modifier.height(24.dp))
            
            Text(
                text = "App Version: 1.0.0",
                style = MaterialTheme.typography.bodySmall,
                modifier = Modifier.align(Alignment.CenterHorizontally)
            )
        }
        
        if (showConfirmDialog) {
            AlertDialog(
                onDismissRequest = { showConfirmDialog = false },
                title = { Text(dialogTitle) },
                text = { Text(dialogMessage) },
                confirmButton = {
                    Button(
                        onClick = {
                            dialogAction()
                            showConfirmDialog = false
                        }
                    ) {
                        Text("Confirm")
                    }
                },
                dismissButton = {
                    TextButton(
                        onClick = { showConfirmDialog = false }
                    ) {
                        Text("Cancel")
                    }
                }
            )
        }
    }
}

@Composable
fun SettingsSwitchItem(
    title: String,
    description: String,
    icon: ImageVector,
    checked: Boolean,
    onCheckedChange: (Boolean) -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(
            imageVector = icon,
            contentDescription = null,
            tint = MaterialTheme.colorScheme.primary,
            modifier = Modifier.size(24.dp)
        )
        
        Column(
            modifier = Modifier
                .weight(1f)
                .padding(horizontal = 16.dp)
        ) {
            Text(
                text = title,
                style = MaterialTheme.typography.titleMedium
            )
            Text(
                text = description,
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
        
        Switch(
            checked = checked,
            onCheckedChange = onCheckedChange
        )
    }
}

@Composable
fun SettingsClickableItem(
    title: String,
    description: String,
    icon: ImageVector,
    onClick: () -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 12.dp)
            .clickable(onClick = onClick),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(
            imageVector = icon,
            contentDescription = null,
            tint = MaterialTheme.colorScheme.primary,
            modifier = Modifier.size(24.dp)
        )
        
        Column(
            modifier = Modifier
                .weight(1f)
                .padding(horizontal = 16.dp)
        ) {
            Text(
                text = title,
                style = MaterialTheme.typography.titleMedium
            )
            Text(
                text = description,
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
        
        Icon(
            imageVector = Icons.Default.ChevronRight,
            contentDescription = null,
            tint = MaterialTheme.colorScheme.onSurfaceVariant,
            modifier = Modifier.size(24.dp)
        )
    }
}
