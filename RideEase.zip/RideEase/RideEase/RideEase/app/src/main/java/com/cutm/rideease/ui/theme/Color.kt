package com.cutm.rideease.ui.theme

import androidx.compose.ui.graphics.Color

// Primary colors
val Primary80 = Color(0xFF4CAF50) // Green
val Secondary80 = Color(0xFF81C784) // Light Green
val Tertiary80 = Color(0xFF2196F3) // Blue

// Dark theme colors
val Primary40 = Color(0xFF2E7D32) // Dark Green
val Secondary40 = Color(0xFF558B2F) // Dark Light Green
val Tertiary40 = Color(0xFF1976D2) // Dark Blue

// Additional colors
val Success = Color(0xFF4CAF50)
val Error = Color(0xFFE57373)
val Warning = Color(0xFFFFB74D)
val Info = Color(0xFF64B5F6)

// Background and surface colors
val Background = Color(0xFFF5F5F5)
val Surface = Color(0xFFFFFFFF)
val OnSurface = Color(0xFF1C1B1F)