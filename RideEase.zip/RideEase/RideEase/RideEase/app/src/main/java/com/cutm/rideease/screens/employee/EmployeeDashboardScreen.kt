package com.cutm.rideease.screens.employee

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Assignment
import androidx.compose.material.icons.filled.Battery6Bar
import androidx.compose.material.icons.filled.DirectionsBike
import androidx.compose.material.icons.filled.Payment
import androidx.compose.material.icons.filled.Feedback
import androidx.compose.material.icons.filled.Build
import androidx.compose.material.icons.filled.Speed
import androidx.compose.material.icons.filled.ElectricCar
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import com.cutm.rideease.navigation.AppRoute

data class CycleStatus(
    val id: String,
    val name: String,
    val type: String,
    val isAvailable: Boolean,
    val lastMaintenance: String,
    val batteryHealth: Int,
    val totalRides: Int,
    val topSpeed: Double,
    val mileage: Double
)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun EmployeeDashboardScreen(
    navController: NavController,
    cycleType: String = "",
    modifier: Modifier = Modifier
) {
    var cycles by remember { mutableStateOf(listOf(
        CycleStatus("M1", "Mountain E-Bike Pro", "Mountain E-Bike", true, "2024-02-15", 90, 150, 25.0, 45.5),
        CycleStatus("M2", "Mountain E-Bike Sport", "Mountain E-Bike", false, "2024-02-10", 85, 120, 23.0, 40.0),
        CycleStatus("M3", "Mountain E-Bike Trail", "Mountain E-Bike", true, "2024-01-30", 75, 200, 28.0, 50.0),
        CycleStatus("C1", "City Cruiser Deluxe", "City Cruiser", true, "2024-02-12", 95, 80, 20.0, 38.0),
        CycleStatus("C2", "City Cruiser Comfort", "City Cruiser", false, "2024-02-05", 80, 110, 18.0, 35.0),
        CycleStatus("C3", "City Cruiser Urban", "City Cruiser", true, "2024-01-25", 70, 130, 22.0, 42.0),
        CycleStatus("S1", "Sport E-Bike Racing", "Sport E-Bike", true, "2024-02-18", 88, 180, 32.0, 48.0),
        CycleStatus("S2", "Sport E-Bike Speed", "Sport E-Bike", false, "2024-02-08", 82, 220, 30.0, 45.0),
        CycleStatus("S3", "Sport E-Bike Pro", "Sport E-Bike", true, "2024-01-20", 78, 250, 28.0, 42.0),
        CycleStatus("R1", "Comfort Rider Plush", "Comfort Rider", true, "2024-02-14", 92, 70, 18.0, 36.0),
        CycleStatus("R2", "Comfort Rider Relax", "Comfort Rider", false, "2024-02-03", 87, 90, 19.0, 38.0),
        CycleStatus("R3", "Comfort Rider Smooth", "Comfort Rider", true, "2024-01-28", 83, 100, 20.0, 40.0)
    )) }

    // Filter cycles based on the selected type
    val filteredCycles = if (cycleType.isNotEmpty()) {
        cycles.filter { it.type == cycleType }
    } else {
        cycles
    }
    
    // Function to update cycle availability
    val updateCycleAvailability = { cycleId: String ->
        cycles = cycles.map { cycle ->
            if (cycle.id == cycleId) {
                cycle.copy(isAvailable = !cycle.isAvailable)
            } else {
                cycle
            }
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(if (cycleType.isNotEmpty()) "$cycleType Management" else "Cycle Management") },
                navigationIcon = {
                    if (cycleType.isNotEmpty()) {
                        IconButton(onClick = { navController.popBackStack() }) {
                            Icon(Icons.Default.ArrowBack, contentDescription = "Back")
                        }
                    }
                },
                actions = {
                    IconButton(onClick = { navController.navigate(AppRoute.Employee.PaymentConfirmation) }) {
                        Icon(Icons.Default.Payment, contentDescription = "Payments")
                    }
                    IconButton(onClick = { navController.navigate(AppRoute.Employee.FeedbackReview) }) {
                        Icon(Icons.Default.Feedback, contentDescription = "Feedback")
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = Color(0xFFFCE93B),
                    titleContentColor = Color.Black,
                    navigationIconContentColor = Color.Black,
                    actionIconContentColor = Color.Black
                )
            )
        }
    ) { padding ->
        if (filteredCycles.isEmpty()) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(padding),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = "No cycles found for this type",
                    style = MaterialTheme.typography.titleMedium
                )
            }
        } else {
            LazyColumn(
                contentPadding = PaddingValues(
                    top = padding.calculateTopPadding(),
                    bottom = padding.calculateBottomPadding() + 16.dp,
                    start = 16.dp,
                    end = 16.dp
                ),
                modifier = modifier.fillMaxSize(),
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                items(
                    items = filteredCycles,
                    key = { it.id }
                ) { cycle ->
                    CycleManagementCard(
                        cycle = cycle,
                        onStatusChange = { updateCycleAvailability(cycle.id) },
                        onMaintenanceLog = { 
                            navController.navigate(AppRoute.Employee.MaintenanceList.replace("{cycleType}", cycle.type))
                        }
                    )
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun CycleManagementCard(
    cycle: CycleStatus,
    onStatusChange: () -> Unit,
    onMaintenanceLog: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
    ) {
        Column(
            modifier = Modifier
                .padding(16.dp)
                .fillMaxWidth()
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = cycle.name,
                    style = MaterialTheme.typography.titleMedium
                )
                Switch(
                    checked = cycle.isAvailable,
                    onCheckedChange = { onStatusChange() }
                )
            }
            
            Spacer(modifier = Modifier.height(8.dp))
            
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceEvenly
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Icon(
                        imageVector = Icons.Default.Battery6Bar,
                        contentDescription = "Battery Health",
                        tint = when {
                            cycle.batteryHealth > 80 -> MaterialTheme.colorScheme.primary
                            cycle.batteryHealth > 50 -> MaterialTheme.colorScheme.secondary
                            else -> MaterialTheme.colorScheme.error
                        }
                    )
                    Text(
                        text = "${cycle.batteryHealth}%",
                        style = MaterialTheme.typography.bodyMedium
                    )
                }
                
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Icon(
                        imageVector = Icons.Default.DirectionsBike,
                        contentDescription = "Total Rides",
                        tint = MaterialTheme.colorScheme.primary
                    )
                    Text(
                        text = "${cycle.totalRides}",
                        style = MaterialTheme.typography.bodyMedium
                    )
                }
                
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Icon(
                        imageVector = Icons.Default.Speed,
                        contentDescription = "Top Speed",
                        tint = MaterialTheme.colorScheme.primary
                    )
                    Text(
                        text = "${cycle.topSpeed} km/h",
                        style = MaterialTheme.typography.bodyMedium
                    )
                }
                
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Icon(
                        imageVector = Icons.Default.ElectricCar,
                        contentDescription = "Mileage",
                        tint = MaterialTheme.colorScheme.primary
                    )
                    Text(
                        text = "${cycle.mileage} km",
                        style = MaterialTheme.typography.bodyMedium
                    )
                }
            }
            
            Spacer(modifier = Modifier.height(16.dp))
            
            Button(
                onClick = onMaintenanceLog,
                modifier = Modifier.fillMaxWidth(),
                colors = ButtonDefaults.buttonColors(
                    containerColor = Color(0xFFFFEB3B),
                    contentColor = Color.Black
                )
            ) {
                Row(
                    horizontalArrangement = Arrangement.Center,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        imageVector = Icons.Default.Build,
                        contentDescription = "Maintenance",
                        modifier = Modifier.size(24.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("Log Maintenance")
                }
            }
            
            Spacer(modifier = Modifier.height(8.dp))
            
            Text(
                text = "Last Maintenance: ${cycle.lastMaintenance}",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
    }
}