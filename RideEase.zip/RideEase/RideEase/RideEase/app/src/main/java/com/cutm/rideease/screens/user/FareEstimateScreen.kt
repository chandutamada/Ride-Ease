package com.cutm.rideease.screens.user

import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import kotlin.math.roundToInt

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun FareEstimateScreen(
    navController: NavController,
    modifier: Modifier = Modifier
) {
    var duration by remember { mutableStateOf(30f) }
    var estimatedFare by remember { mutableStateOf(calculateFare(duration.roundToInt())) }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Fare Estimate") },
                navigationIcon = {
                    IconButton(onClick = { navController.navigateUp() }) {
                        Icon(Icons.Default.ArrowBack, contentDescription = "Back")
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = Color(0xFFFFEB3B),
                    titleContentColor = Color.Black,
                    navigationIconContentColor = Color.Black,
                    actionIconContentColor = Color.Black
                )
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(horizontal = 16.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(24.dp)
        ) {
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = Color(0xFFFFEB3B))
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Text(
                        text = "₹${estimatedFare}",
                        style = MaterialTheme.typography.displayLarge,
                        color = Color.Black
                    )
                    Text(
                        text = "Estimated Fare",
                        style = MaterialTheme.typography.titleMedium,
                        color = Color.Black.copy(alpha = 0.7f)
                    )
                }
            }

            Text(
                text = "Duration: ${duration.roundToInt()} minutes",
                style = MaterialTheme.typography.titleMedium,
                color = Color.Black
            )

            Slider(
                value = duration,
                onValueChange = {
                    duration = it
                    estimatedFare = calculateFare(it.roundToInt())
                },
                valueRange = 5f..120f,
                steps = 22,
                colors = SliderDefaults.colors(
                    thumbColor = Color(0xFFFFEB3B),
                    activeTrackColor = Color(0xFFFFEB3B),
                    inactiveTrackColor = Color(0xFFFFEB3B).copy(alpha = 0.3f)
                )
            )

            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = Color(0xFFF5F5F5))
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp)
                ) {
                    Text(
                        text = "Fare Breakdown",
                        style = MaterialTheme.typography.titleMedium,
                        color = Color.Black
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(
                            text = "Base Fare",
                            color = Color.Black.copy(alpha = 0.7f)
                        )
                        Text(
                            text = "₹20",
                            color = Color.Black
                        )
                    }
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(
                            text = "Per Minute Rate",
                            color = Color.Black.copy(alpha = 0.7f)
                        )
                        Text(
                            text = "₹2",
                            color = Color.Black
                        )
                    }
                }
            }
        }
    }
}

private fun calculateFare(durationMinutes: Int): Int {
    val baseFare = 20
    val perMinuteRate = 2
    return baseFare + (durationMinutes * perMinuteRate)
}
