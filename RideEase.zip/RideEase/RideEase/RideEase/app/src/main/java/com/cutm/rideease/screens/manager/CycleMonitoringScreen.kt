package com.cutm.rideease.screens.manager

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import java.text.SimpleDateFormat
import java.util.*

data class CycleStatus(
    val id: String,
    val name: String,
    val type: String,
    val batteryHealth: Int,
    val lastMaintenance: Date,
    val nextMaintenance: Date,
    val status: String,
    val location: String,
    val totalRides: Int
)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun CycleMonitoringScreen(navController: NavController) {
    val dateFormat = remember { SimpleDateFormat("MMM dd, yyyy", Locale.getDefault()) }
    
    var cycles by remember {
        mutableStateOf(listOf(
            CycleStatus(
                "C1", "City Cruiser", "City", 85,
                Date(System.currentTimeMillis() - 86400000 * 7),
                Date(System.currentTimeMillis() + 86400000 * 30),
                "Available", "Parking Zone A", 45
            ),
            CycleStatus(
                "M1", "Mountain Pro", "Mountain", 72,
                Date(System.currentTimeMillis() - 86400000 * 14),
                Date(System.currentTimeMillis() + 86400000 * 15),
                "Maintenance", "Service Center", 82
            )
        ))
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Cycle Monitoring") },
                navigationIcon = {
                    IconButton(onClick = { navController.popBackStack() }) {
                        Icon(Icons.Default.ArrowBack, "Back")
                    }
                },
                actions = {
                    IconButton(onClick = { /* Open filters */ }) {
                        Icon(Icons.Default.Tune, "Filter")
                    }
                }
            )
        }
    ) { padding ->
        LazyColumn(
            modifier = Modifier
                .padding(padding)
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            items(cycles) { cycle ->
                CycleStatusCard(cycle, dateFormat)
            }
        }
    }
}

@Composable
private fun CycleStatusCard(cycle: CycleStatus, dateFormat: SimpleDateFormat) {
    Card(
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(
            modifier = Modifier.padding(16.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "${cycle.name} (${cycle.id})",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold
                )
                
                Badge(
                    containerColor = when(cycle.status) {
                        "Available" -> Color.Green.copy(alpha = 0.2f)
                        "Maintenance" -> Color.Red.copy(alpha = 0.2f)
                        else -> Color.Gray.copy(alpha = 0.2f)
                    }
                ) {
                    Text(
                        text = cycle.status,
                        color = when(cycle.status) {
                            "Available" -> Color.Green
                            "Maintenance" -> Color.Red
                            else -> Color.Gray
                        }
                    )
                }
            }

            Spacer(modifier = Modifier.height(8.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                InfoColumn("Battery Health", "${cycle.batteryHealth}%", Icons.Default.BatteryFull)
                InfoColumn("Total Rides", cycle.totalRides.toString(), Icons.Default.DirectionsBike)
                InfoColumn("Location", cycle.location, Icons.Default.LocationOn)
            }

            Spacer(modifier = Modifier.height(12.dp))

            MaintenanceInfoRow(
                label = "Last Maintenance",
                value = dateFormat.format(cycle.lastMaintenance),
                icon = Icons.Default.History
            )

            MaintenanceInfoRow(
                label = "Next Maintenance",
                value = dateFormat.format(cycle.nextMaintenance),
                icon = Icons.Default.Upcoming
            )
        }
    }
}

@Composable
private fun InfoColumn(label: String, value: String, icon: androidx.compose.ui.graphics.vector.ImageVector) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(
                imageVector = icon,
                contentDescription = label,
                modifier = Modifier.size(16.dp)
            )
            Spacer(modifier = Modifier.width(4.dp))
            Text(text = label, style = MaterialTheme.typography.labelSmall)
        }
        Text(text = value, style = MaterialTheme.typography.bodyMedium)
    }
}

@Composable
private fun MaintenanceInfoRow(label: String, value: String, icon: androidx.compose.ui.graphics.vector.ImageVector) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(
            imageVector = icon,
            contentDescription = label,
            modifier = Modifier.size(20.dp)
        )
        Spacer(modifier = Modifier.width(8.dp))
        Column {
            Text(text = label, style = MaterialTheme.typography.labelSmall)
            Text(text = value, style = MaterialTheme.typography.bodyMedium)
        }
    }
}