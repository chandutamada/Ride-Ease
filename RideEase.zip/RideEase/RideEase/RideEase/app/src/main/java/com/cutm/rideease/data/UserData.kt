package com.cutm.rideease.data

data class UserData(
    val id: String,
    val name: String,
    val role: String,
    val email: String
)