package com.cutm.rideease.screens.manager

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import com.cutm.rideease.navigation.AppRoute

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ManagerDashboardScreen(navController: NavController) {
    val menuItems = listOf(
        "Revenue" to AppRoute.Manager.Revenue,
        "Analytics" to AppRoute.Manager.Analytics,
        "User Management" to AppRoute.Manager.UserManagement,
        "Maintenance" to AppRoute.Manager.Maintenance,
        "Feedback" to AppRoute.Manager.FeedbackSystem,
        "Settings" to AppRoute.Manager.Settings
    )

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Manager Dashboard") }
            )
        }
    ) { padding ->
        LazyVerticalGrid(
            columns = GridCells.Fixed(2),
            modifier = Modifier
                .fillMaxSize()
                .padding(padding),
            contentPadding = PaddingValues(16.dp),
            horizontalArrangement = Arrangement.spacedBy(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            items(menuItems.size) { index ->
                val (title, route) = menuItems[index]
                Card(
                    onClick = { navController.navigate(route) },
                    modifier = Modifier.height(120.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(16.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = title,
                            style = MaterialTheme.typography.titleMedium
                        )
                    }
                }
            }
        }
    }
}